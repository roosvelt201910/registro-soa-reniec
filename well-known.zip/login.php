<?php
// Iniciar sesión al principio
session_start();

// Verificar si ya está logueado
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dni = isset($_POST['dni']) ? trim($_POST['dni']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    if (empty($dni) || empty($password)) {
        $error = 'Por favor, complete todos los campos.';
    } else {
        try {
            // Configuración de base de datos
            $host = "localhost";
            $db_name = "iespaltohuallaga_regauxiliar_bd";
            $username = "iespaltohuallaga_user_regaux";
            $db_password = ")wBRCeID[ldb%b^K";
            
            $conn = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8", $username, $db_password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $query = "SELECT id, dni, nombres, apellidos, tipo_usuario, estado, password FROM usuarios WHERE dni = :dni AND estado = 'activo'";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':dni', $dni);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verificar contraseña (con hash o sin hash para compatibilidad)
                $password_valid = false;
                
                // Método 1: Verificar con password_verify (contraseñas hasheadas)
                if (password_verify($password, $user['password'])) {
                    $password_valid = true;
                }
                // Método 2: Verificar directamente (contraseñas sin hash - temporal)
                elseif ($password === $user['password']) {
                    $password_valid = true;
                    // Actualizar a hash seguro automáticamente
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $update_query = "UPDATE usuarios SET password = :password WHERE id = :id";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bindParam(':password', $hashed_password);
                    $update_stmt->bindParam(':id', $user['id']);
                    $update_stmt->execute();
                }
                
                if ($password_valid) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_dni'] = $user['dni'];
                    $_SESSION['user_name'] = $user['nombres'] . ' ' . $user['apellidos'];
                    $_SESSION['user_type'] = $user['tipo_usuario'];
                    $_SESSION['logged_in'] = true;
                    
                    header('Location: dashboard.php');
                    exit();
                } else {
                    $error = 'DNI o contraseña incorrectos.';
                }
            } else {
                $error = 'DNI o contraseña incorrectos.';
            }
        } catch(PDOException $e) {
            $error = 'Error de conexión a la base de datos. Verifique la configuración.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Académico - Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        :root {
            --primary-color: #082678ff;
            --primary-dark: #0f0a6eff;
            --secondary-color: #0c2052ff;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --light-color: #f9fafb;
            --dark-color: #1f2937;
            --border-color: #e5e7eb;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-size: 200% 200%;
            animation: gradientBG 8s ease infinite;
            -webkit-font-smoothing: antialiased;
            position: relative;
            overflow: hidden;
        }
        
        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        /* Canvas para efectos de partículas */
        .particles-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            pointer-events: none;
        }
        
        /* Contenedor de electrones flotantes */
        .electrons-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 2;
            pointer-events: none;
        }
        
        /* Electrones individuales */
        .electron {
            position: absolute;
            width: 8px;
            height: 8px;
            background: radial-gradient(circle, #00ffff 0%, #0066ff 50%, transparent 100%);
            border-radius: 50%;
            box-shadow: 
                0 0 10px #00ffff,
                0 0 20px #00ffff,
                0 0 30px #00ffff;
            animation: electronFloat 15s infinite linear;
        }
        
        .electron:nth-child(odd) {
            animation-direction: reverse;
            background: radial-gradient(circle, #ff00ff 0%, #6600ff 50%, transparent 100%);
            box-shadow: 
                0 0 10px #ff00ff,
                0 0 20px #ff00ff,
                0 0 30px #ff00ff;
        }
        
        .electron:nth-child(3n) {
            background: radial-gradient(circle, #ffff00 0%, #ff6600 50%, transparent 100%);
            box-shadow: 
                0 0 10px #ffff00,
                0 0 20px #ffff00,
                0 0 30px #ffff00;
            animation-duration: 20s;
        }
        
        @keyframes electronFloat {
            0% {
                transform: translateX(-50px) translateY(100vh) rotate(0deg);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateX(calc(100vw + 50px)) translateY(-50px) rotate(360deg);
                opacity: 0;
            }
        }
        
        /* Efectos de explosión */
        .explosion {
            position: absolute;
            width: 7px;
            height: 7px;
            background: #fff;
            border-radius: 50%;
            pointer-events: none;
            z-index: 3;
        }
        
        .explosion::before,
        .explosion::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: inherit;
            border-radius: 50%;
        }
        
        .explosion::before {
            animation: explosionParticle1 1s ease-out forwards;
        }
        
        .explosion::after {
            animation: explosionParticle2 1s ease-out forwards;
        }
        
        @keyframes explosionParticle1 {
            0% {
                transform: scale(1) translateX(0);
                opacity: 1;
                background: #ff6b6b;
                box-shadow: 0 0 10px #ff6b6b;
            }
            100% {
                transform: scale(0) translateX(100px);
                opacity: 0;
                background: #ff0000;
            }
        }
        
        @keyframes explosionParticle2 {
            0% {
                transform: scale(1) translateY(0);
                opacity: 1;
                background: #4ecdc4;
                box-shadow: 0 0 10px #4ecdc4;
            }
            100% {
                transform: scale(0) translateY(-100px);
                opacity: 0;
                background: #00ffff;
            }
        }
        
        /* Ondas de energía */
        .energy-wave {
            position: absolute;
            border: 2px solid #00ffff;
            border-radius: 50%;
            opacity: 0;
            animation: energyWave 4s ease-out infinite;
        }
        
        @keyframes energyWave {
            0% {
                width: 10px;
                height: 10px;
                opacity: 1;
                box-shadow: 0 0 10px #00ffff;
            }
            100% {
                width: 300px;
                height: 300px;
                opacity: 0;
                box-shadow: 0 0 50px #00ffff;
            }
        }
        
        /* Chispas eléctricas */
        .electric-spark {
            position: absolute;
            width: 2px;
            height: 20px;
            background: linear-gradient(0deg, transparent, #fff, #00ffff, transparent);
            animation: electricSpark 0.1s ease-in-out infinite alternate;
            transform-origin: bottom;
        }
        
        @keyframes electricSpark {
            0% {
                transform: rotate(-5deg) scaleY(0.8);
                opacity: 0.8;
            }
            100% {
                transform: rotate(5deg) scaleY(1.2);
                opacity: 1;
            }
        }
        
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: var(--shadow-xl);
            width: 100%;
            max-width: 480px;
            transform: translateY(20px);
            opacity: 0;
            animation: fadeInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1) forwards;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            overflow: hidden;
            position: relative;
            z-index: 10;
        }
        
        @keyframes fadeInUp {
            to { transform: translateY(0); opacity: 1; }
        }
        
        .login-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(99, 102, 241, 0.1) 0%, rgba(0, 0, 0, 0) 70%);
            z-index: 0;
            animation: containerGlow 4s ease-in-out infinite alternate;
        }
        
        @keyframes containerGlow {
            0% {
                opacity: 0.3;
                transform: rotate(0deg);
            }
            100% {
                opacity: 0.6;
                transform: rotate(180deg);
            }
        }
        
        .logo {
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
            z-index: 1;
        }
        
        .logo-icon {
            width: 180px;
            height: 180px;
            border-radius: 10%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            box-shadow: var(--shadow-md);
            animation: logoFloat 3s ease-in-out infinite;
            position: relative;
            overflow: hidden;
        }
        
        .logo-icon::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.81), transparent);
            animation: logoSpin 2s linear infinite;
        }
        
        @keyframes logoFloat {
            0%, 100% { 
                transform: translateY(0px) scale(1);
                box-shadow: 
                    var(--shadow-md),
                    0 0 20px rgba(8, 38, 120, 0.3);
            }
            50% { 
                transform: translateY(-10px) scale(1.05);
                box-shadow: 
                    var(--shadow-lg),
                    0 0 30px rgba(8, 38, 120, 0.5);
            }
        }
        
        @keyframes logoSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .logo-icon i {
            color: white;
            font-size: 1.8rem;
            z-index: 2;
            position: relative;
            text-shadow: 0 0 10px rgba(255,255,255,0.5);
        }
        
        .logo h1 {
            color: var(--dark-color);
            font-size: 1.75rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
            animation: titleGlow 2s ease-in-out infinite alternate;
        }
        
        @keyframes titleGlow {
            0% { text-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            100% { text-shadow: 0 2px 4px rgba(0,0,0,0.1), 0 0 10px rgba(8, 38, 120, 0.3); }
        }
        
        .logo p {
            color: #6b7280;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
            z-index: 1;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--dark-color);
            font-weight: 500;
            font-size: 0.95rem;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.9rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            transition: var(--transition);
            background-color: rgba(255, 255, 255, 0.8);
            box-shadow: var(--shadow-sm);
            position: relative;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2), 0 0 20px rgba(8, 38, 120, 0.2);
            background-color: rgba(255, 255, 255, 0.95);
        }
        
        .btn {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            z-index: 1;
            box-shadow: var(--shadow-md);
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg), 0 0 20px rgba(8, 38, 120, 0.4);
        }
        
        .btn:hover::before {
            left: 100%;
        }
        
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 38px;
            cursor: pointer;
            color: #9ca3af;
            transition: var(--transition);
        }
        
        .password-toggle:hover {
            color: var(--primary-color);
            text-shadow: 0 0 5px var(--primary-color);
        }
        
        /* Efecto de onda al hacer clic */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.6);
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
            mix-blend-mode: overlay;
        }
        
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        /* Personalización de SweetAlert2 */
        .swal2-popup {
            background: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(15px) !important;
            border-radius: 20px !important;
            box-shadow: 
                0 25px 50px -12px rgba(0, 0, 0, 0.25),
                0 0 50px rgba(8, 38, 120, 0.3) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        
        .swal2-title {
            color: var(--dark-color) !important;
            font-family: 'Inter', sans-serif !important;
            font-weight: 700 !important;
        }
        
        .swal2-html-container {
            color: #4b5563 !important;
            font-family: 'Inter', sans-serif !important;
        }
        
        .swal2-confirm {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            border: none !important;
            border-radius: 10px !important;
            font-weight: 600 !important;
            padding: 12px 24px !important;
        }
        
        .swal2-cancel {
            background: #6c757d !important;
            border: none !important;
            border-radius: 10px !important;
            font-weight: 600 !important;
            padding: 12px 24px !important;
            margin-right: 10px !important;
        }
        
        .security-info {
            margin-top: 1.5rem;
            padding: 1rem;
            background-color: rgba(249, 250, 251, 0.9);
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
            position: relative;
            z-index: 1;
            transform: translateY(20px);
            opacity: 0;
            animation: fadeInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1) 0.3s forwards;
            backdrop-filter: blur(5px);
        }
        
        .security-info h4 {
            color: var(--dark-color);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .security-info h4 i {
            color: var(--primary-color);
        }
        
        .security-info p {
            font-size: 0.85rem;
            color: #4b5563;
            line-height: 1.4;
            margin: 0;
        }
        
        @media (max-width: 480px) {
            .login-container {
                margin: 1.25rem;
                padding: 1.75rem 1.5rem;
                border-radius: 12px;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .logo p {
                font-size: 0.9rem;
            }
            
            .btn {
                padding: 0.9rem;
            }
            
            .electron {
                width: 6px;
                height: 6px;
            }
        }
    </style>
</head>
<body>
    <!-- Canvas para efectos de partículas -->
    <canvas class="particles-canvas" id="particlesCanvas"></canvas>
    
    <!-- Contenedor de electrones -->
    <div class="electrons-container" id="electronsContainer"></div>
    
    <!-- Contenedor principal de login -->
    <div class="login-container">
        <div class="logo">
            <div class="logo-icon">
                <img class="loguito" src="img/univer.png" style="width:170px; height:170px; object-fit:contain;" />
            </div>
            <h1>Sistema Académico</h1>
            <p>IESTP "Alto Huallaga" - Tocache</p>
        </div>
        
        <form method="POST" action="" id="loginForm">
            <div class="form-group">
                <label for="dni">DNI:</label>
                <input type="text" id="dni" name="dni" maxlength="8" pattern="[0-9]{8}" required placeholder="Ingrese su DNI">
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required placeholder="Ingrese su contraseña">
                <i class="fas fa-eye password-toggle" id="togglePassword"></i>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
            </button>
        </form>
        
        <div class="security-info">
            <h4><i class="fas fa-shield-alt"></i> Información de Seguridad</h4>
            <p>Sus datos están protegidos mediante encriptación. Si olvidó su contraseña, contacte al administrador del sistema.</p>
        </div>
    </div>
    
    <!-- SweetAlert2 JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
    
    <script>
        // Verificar que SweetAlert2 se cargó
        console.log('SweetAlert2 disponible:', typeof Swal !== 'undefined');
        
        // Función para crear explosiones
        function createExplosion(x, y, color = '#ff6b6b', count = 20) {
            for (let i = 0; i < count; i++) {
                setTimeout(() => {
                    const explosion = document.createElement('div');
                    explosion.className = 'explosion';
                    explosion.style.left = x + 'px';
                    explosion.style.top = y + 'px';
                    explosion.style.background = color;
                    explosion.style.boxShadow = `0 0 10px ${color}`;
                    
                    document.body.appendChild(explosion);
                    
                    setTimeout(() => {
                        if (explosion.parentNode) {
                            explosion.parentNode.removeChild(explosion);
                        }
                    }, 1000);
                }, i * 50);
            }
        }
        
        // Función para crear ondas de energía
        function createEnergyWave(x, y, color = '#00ffff') {
            for (let i = 0; i < 3; i++) {
                setTimeout(() => {
                    const wave = document.createElement('div');
                    wave.className = 'energy-wave';
                    wave.style.left = x + 'px';
                    wave.style.top = y + 'px';
                    wave.style.borderColor = color;
                    wave.style.boxShadow = `0 0 20px ${color}`;
                    
                    document.body.appendChild(wave);
                    
                    setTimeout(() => {
                        if (wave.parentNode) {
                            wave.parentNode.removeChild(wave);
                        }
                    }, 4000);
                }, i * 300);
            }
        }
        
        // Crear electrones flotantes
        function createElectrons() {
            setInterval(() => {
                const electron = document.createElement('div');
                electron.className = 'electron';
                electron.style.left = Math.random() * 100 + 'vw';
                electron.style.top = Math.random() * 100 + 'vh';
                
                document.getElementById('electronsContainer').appendChild(electron);
                
                setTimeout(() => {
                    if (electron.parentNode) {
                        electron.parentNode.removeChild(electron);
                    }
                }, 15000);
            }, 500);
        }
        
        // Crear explosiones aleatorias
        function createRandomExplosions() {
            setInterval(() => {
                const x = Math.random() * window.innerWidth;
                const y = Math.random() * window.innerHeight;
                createExplosion(x, y, '#6366f1', 10);
            }, 3000);
        }
        
        // Toast personalizado
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true
        });
        
        // Inicialización cuando se carga la página
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Página cargada, iniciando efectos...');
            
            // Inicializar efectos
            createElectrons();
            createRandomExplosions();
            
            // Mostrar error PHP si existe
            <?php if (!empty($error)): ?>
                Swal.fire({
                    icon: 'error',
                    title: '¡Error de Autenticación!',
                    text: '<?php echo addslashes($error); ?>',
                    confirmButtonText: '<i class="fas fa-times"></i> Cerrar'
                }).then(() => {
                    // Crear explosiones de error
                    const centerX = window.innerWidth / 2;
                    const centerY = window.innerHeight / 2;
                    createExplosion(centerX, centerY, '#ef4444', 25);
                });
            <?php endif; ?>
            
            // Validación de DNI en tiempo real
            document.getElementById('dni').addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 8) {
                    value = value.substring(0, 8);
                    Toast.fire({
                        icon: 'warning',
                        title: 'El DNI debe tener máximo 8 dígitos'
                    });
                }
                e.target.value = value;
                
                if (value.length === 8) {
                    e.target.style.borderColor = '#10b981';
                    e.target.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.2)';
                    
                    // Efecto de éxito
                    const rect = e.target.getBoundingClientRect();
                    createExplosion(rect.right - 20, rect.top + rect.height/2, '#10b981', 5);
                } else if (value.length > 0) {
                    e.target.style.borderColor = '#ffc107';
                    e.target.style.boxShadow = '0 0 0 3px rgba(255, 193, 7, 0.2)';
                } else {
                    e.target.style.borderColor = '';
                    e.target.style.boxShadow = '';
                }
            });
            
            // Toggle contraseña
            document.getElementById('togglePassword').addEventListener('click', function() {
                const password = document.getElementById('password');
                const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                password.setAttribute('type', type);
                this.classList.toggle('fa-eye-slash');
                this.classList.toggle('fa-eye');
                
                // Efecto visual
                const rect = this.getBoundingClientRect();
                createExplosion(rect.left + rect.width/2, rect.top + rect.height/2, '#6366f1', 8);
                
                Toast.fire({
                    icon: 'info',
                    title: type === 'text' ? 'Contraseña visible 👁️' : 'Contraseña oculta 🔒'
                });
            });
            
            // Manejo del formulario
            document.getElementById('loginForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const dni = document.getElementById('dni').value.trim();
                const password = document.getElementById('password').value.trim();
                
                // Validaciones
                if (!dni || !password) {
                    Swal.fire({
                        icon: 'warning',
                        title: '¡Campos Incompletos!',
                        text: 'Por favor, complete todos los campos requeridos.',
                        confirmButtonText: '<i class="fas fa-exclamation-triangle"></i> Entendido'
                    });
                    return;
                }
                
                if (dni.length !== 8 || !/^\d{8}$/.test(dni)) {
                    Swal.fire({
                        icon: 'error',
                        title: '¡DNI Inválido!',
                        text: 'El DNI debe contener exactamente 8 dígitos numéricos.',
                        confirmButtonText: '<i class="fas fa-times"></i> Cerrar'
                    });
                    document.getElementById('dni').focus();
                    return;
                }
                
                // Efectos de procesamiento
                const btn = this.querySelector('.btn');
                const btnRect = btn.getBoundingClientRect();
                createExplosion(btnRect.left + btnRect.width/2, btnRect.top + btnRect.height/2, '#6366f1', 15);
                createEnergyWave(btnRect.left + btnRect.width/2, btnRect.top + btnRect.height/2, '#6366f1');
                
                // Loading
                Swal.fire({
                    title: '🚀 Validando credenciales...',
                    text: 'Verificando sus datos de acceso',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => {
                        Swal.showLoading();
                    }
                });
                
                // Simular procesamiento y enviar formulario
                setTimeout(() => {
                    this.submit();
                }, 2000);
            });
            
            // Efectos en foco de inputs
            const inputs = document.querySelectorAll('input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.querySelector('label').style.color = 'var(--primary-color)';
                    
                    // Crear chispas
                    for (let i = 0; i < 5; i++) {
                        setTimeout(() => {
                            const spark = document.createElement('div');
                            spark.className = 'electric-spark';
                            spark.style.left = (this.offsetLeft + Math.random() * this.offsetWidth) + 'px';
                            spark.style.top = (this.offsetTop + this.offsetHeight) + 'px';
                            spark.style.transform = `rotate(${Math.random() * 360}deg)`;
                            
                            this.parentElement.appendChild(spark);
                            
                            setTimeout(() => {
                                if (spark.parentNode) {
                                    spark.parentNode.removeChild(spark);
                                }
                            }, 1000);
                        }, i * 100);
                    }
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.querySelector('label').style.color = 'var(--dark-color)';
                });
            });
            
            // Efecto de onda en botones
            document.addEventListener('click', function(e) {
                if (e.target.closest('.btn')) {
                    const btn = e.target.closest('.btn');
                    const ripple = document.createElement('span');
                    const rect = btn.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    const x = e.clientX - rect.left - size / 2;
                    const y = e.clientY - rect.top - size / 2;
                    
                    ripple.style.width = ripple.style.height = size + 'px';
                    ripple.style.left = x + 'px';
                    ripple.style.top = y + 'px';
                    ripple.classList.add('ripple');
                    
                    btn.appendChild(ripple);
                    
                    setTimeout(() => {
                        ripple.remove();
                    }, 600);
                }
            });
            
            // Mensaje de bienvenida
            setTimeout(() => {
                <?php if (empty($error)): ?>
                    Toast.fire({
                        icon: 'info',
                        title: '¡Bienvenido al Sistema Académico! 🎓'
                    });
                <?php endif; ?>
            }, 2000);
            
            // Atajos de teclado
            document.addEventListener('keydown', function(e) {
                if (e.key === 'F1') {
                    e.preventDefault();
                    Swal.fire({
                        title: '🚀 Sistema Académico - Ayuda',
                        html: `
                            <div style="text-align: left; line-height: 1.6;">
                                <h4>🎯 Instrucciones de Acceso:</h4>
                                <p><strong>1.</strong> Ingrese su DNI (8 dígitos)</p>
                                <p><strong>2.</strong> Ingrese su contraseña</p>
                                <p><strong>3.</strong> Haga clic en "Iniciar Sesión"</p>
                                
                                <h4>💡 Consejos:</h4>
                                <p>• Verifique que su DNI esté correcto</p>
                                <p>• Si olvidó su contraseña, contacte al administrador</p>
                                <p>• Presione F1 para mostrar esta ayuda</p>
                                
                                <h4>🔒 Seguridad:</h4>
                                <p>• Sus datos están protegidos con encriptación</p>
                                <p>• No comparta sus credenciales</p>
                            </div>
                        `,
                        confirmButtonText: '¡Entendido!'
                    });
                }
                
                if (e.ctrlKey && e.key === 'Enter') {
                    e.preventDefault();
                    document.getElementById('loginForm').dispatchEvent(new Event('submit'));
                }
            });
        });
        
        console.log('🎉 Sistema de Login completamente cargado');
    </script>
</body>
</html>