<?php
// registro_usuario.php - Sistema de Registro Académico con Auto-completado DNI
session_start();

// ==================== CONFIGURACIÓN DE BASE DE DATOS ====================
$db_host = 'localhost';
$db_user = 'iespaltohuallaga_user_regaux';
$db_pass = ')wBRCeID[ldb%b^K';
$db_name = 'iespaltohuallaga_regauxiliar_bd';

// Crear conexión
$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecer charset UTF-8
$conexion->set_charset("utf8mb4");
date_default_timezone_set('America/Lima');

// ==================== FUNCIONES DE CONSULTA DNI ====================
function consultarDNIDirecto($dni) {
    // Token de Decolecta - REEMPLAZAR con tu token real si está configurado
    $token = 'sk_10367.GU4w1AirWvIqPecMayNcvlSK3RbE5H4v'; // Usar tu token real aquí
    
    // Log de consulta
    error_log("Consultando DNI: " . $dni . " - " . date('Y-m-d H:i:s'));
    
    // Datos de prueba extendidos para testing
    $datosPrueba = [
        '71882580' => ['nombres' => 'ENMANUEL ALEJANDRO', 'apellidos' => 'MILLONES '],
        '12345678' => ['nombres' => 'JUAN CARLOS', 'apellidos' => 'PEREZ LOPEZ'],
        '87654321' => ['nombres' => 'MARIA ELENA', 'apellidos' => 'SANCHEZ TORRES'],
        '11111111' => ['nombres' => 'ANA SOFIA', 'apellidos' => 'MENDOZA VARGAS'],
        '22222222' => ['nombres' => 'PEDRO ANTONIO', 'apellidos' => 'FLORES CASTILLO'],
        '33333333' => ['nombres' => 'LUCIA BEATRIZ', 'apellidos' => 'GUTIERREZ RAMOS'],
        '44444444' => ['nombres' => 'MIGUEL ANGEL', 'apellidos' => 'TORRES SILVA'],
        '55555555' => ['nombres' => 'CARMEN ROSA', 'apellidos' => 'VEGA MORALES'],
        '66666666' => ['nombres' => 'JOSE LUIS', 'apellidos' => 'HERRERA CASTRO'],
        '77777777' => ['nombres' => 'PATRICIA ELENA', 'apellidos' => 'ROJAS VARGAS'],
        '46027897' => ['nombres' => 'ERACLEO JUAN', 'apellidos' => 'HUAMANI MENDOZA']
    ];
    
    // Intentar con API oficial de Decolecta primero
    if (!empty($token) && $token !== 'TU_NUEVO_TOKEN_DECOLECTA') {
        try {
            // API oficial según documentación
            $url = "https://api.decolecta.com/v1/reniec/dni?numero=" . $dni;
            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token,
                'User-Agent: Sistema-Registro-Academico/3.0'
            ];
            
            $context = stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'header' => implode("\r\n", $headers),
                    'timeout' => 15,
                    'ignore_errors' => true
                ]
            ]);
            
            $response = @file_get_contents($url, false, $context);
            
            if ($response !== false) {
                $data = json_decode($response, true);
                
                // Verificar estructura según documentación oficial
                if (isset($data['first_name']) && isset($data['first_last_name'])) {
                    $nombres = strtoupper(trim($data['first_name']));
                    $apellidoPaterno = strtoupper(trim($data['first_last_name']));
                    $apellidoMaterno = strtoupper(trim($data['second_last_name'] ?? ''));
                    $apellidos = trim($apellidoPaterno . ' ' . $apellidoMaterno);
                    
                    error_log("DNI encontrado en Decolecta: " . $dni);
                    return [
                        'success' => true,
                        'nombres' => $nombres,
                        'apellidos' => $apellidos,
                        'service' => 'decolecta_reniec'
                    ];
                }
            }
        } catch (Exception $e) {
            error_log("Error consultando Decolecta: " . $e->getMessage());
        }
    }
    
    // Si falla Decolecta, usar datos de prueba
    if (isset($datosPrueba[$dni])) {
        error_log("DNI encontrado en datos de prueba: " . $dni);
        return [
            'success' => true,
            'nombres' => $datosPrueba[$dni]['nombres'],
            'apellidos' => $datosPrueba[$dni]['apellidos'],
            'service' => 'datos_prueba'
        ];
    }
    
    // Intentar con API alternativa como último recurso
    try {
        $tokenAlt = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6InRlc3RAdGVzdC5jb20ifQ.TSLLVm2Fsd5jpVBJZsVJfbLNLcDblrcE_2QlkmYoZAE';
        $urlAlt = "https://dniruc.apisperu.com/api/v1/dni/" . $dni . "?token=" . $tokenAlt;
        
        $contextAlt = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 10,
                'header' => 'User-Agent: Sistema-Registro-Academico/3.0'
            ]
        ]);
        
        $responseAlt = @file_get_contents($urlAlt, false, $contextAlt);
        
        if ($responseAlt !== false) {
            $dataAlt = json_decode($responseAlt, true);
            if (isset($dataAlt['nombres']) && !empty($dataAlt['nombres'])) {
                error_log("DNI encontrado en API alternativa: " . $dni);
                return [
                    'success' => true,
                    'nombres' => strtoupper(trim($dataAlt['nombres'])),
                    'apellidos' => strtoupper(trim($dataAlt['apellidoPaterno'] . ' ' . $dataAlt['apellidoMaterno'])),
                    'service' => 'api_alternativa'
                ];
            }
        }
    } catch (Exception $e) {
        error_log("Error consultando API alternativa: " . $e->getMessage());
    }
    
    error_log("DNI no encontrado: " . $dni);
    return ['success' => false, 'error' => 'DNI no encontrado en ninguna fuente'];
}

// ==================== VARIABLES ====================
$mensaje = '';
$tipo_mensaje = '';
$ultimo_registro = null;
$registro_exitoso = false;
$datos_dni = null;

// ==================== CONSULTA DNI AUTOMÁTICA ====================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['consultar_dni'])) {
    $dni = trim($_POST['dni']);
    
    if (preg_match('/^[0-9]{8}$/', $dni)) {
        $datos_dni = consultarDNIDirecto($dni);
        
        if ($datos_dni['success']) {
            // Almacenar datos en sesión para prellenar formulario
            $_SESSION['dni_data'] = $datos_dni;
            $_SESSION['dni_consultado'] = $dni;
        }
    } else {
        $datos_dni = ['success' => false, 'error' => 'DNI debe tener exactamente 8 dígitos'];
    }
    
    // Respuesta JSON para JavaScript
    header('Content-Type: application/json');
    echo json_encode($datos_dni, JSON_UNESCAPED_UNICODE);
    exit;
}

// ==================== PROCESAR REGISTRO ====================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['registrar'])) {
    // Recibir y limpiar datos
    $dni = trim($_POST['dni']);
    $nombres = strtoupper(trim($_POST['nombres']));
    $apellidos = strtoupper(trim($_POST['apellidos']));
    $email = trim($_POST['email']);
    $tipo_usuario = $_POST['tipo_usuario'];
    
    // La contraseña será el mismo DNI
    $password = $dni;
    
    // Validaciones robustas
    $errores = [];
    
    // Validar DNI (exactamente 8 dígitos)
    if (!preg_match('/^[0-9]{8}$/', $dni)) {
        $errores[] = "El DNI debe tener exactamente 8 dígitos numéricos";
    }
    
    // Validar nombres y apellidos (solo letras y espacios)
    if (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/", $nombres)) {
        $errores[] = "Los nombres solo pueden contener letras y espacios";
    }
    
    if (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/", $apellidos)) {
        $errores[] = "Los apellidos solo pueden contener letras y espacios";
    }
    
    // Validar email si se proporciona
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El formato del email no es válido";
    }
    
    // Validar tipo de usuario
    if (!in_array($tipo_usuario, ['estudiante', 'docente'])) {
        $errores[] = "Tipo de usuario no válido";
    }
    
    // Verificar si el DNI ya existe
    $stmt = $conexion->prepare("SELECT id, CONCAT(apellidos, ', ', nombres) as nombre_completo FROM usuarios WHERE dni = ?");
    $stmt->bind_param("s", $dni);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $usuario_existente = $result->fetch_assoc();
        $errores[] = "Ya existe un usuario con DNI $dni: " . $usuario_existente['nombre_completo'];
    }
    
    // Si no hay errores, proceder con el registro
    if (empty($errores)) {
        // Encriptar contraseña (que es el DNI)
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        // Iniciar transacción
        $conexion->begin_transaction();
        
        try {
            // Insertar usuario
            $stmt = $conexion->prepare("INSERT INTO usuarios (dni, nombres, apellidos, email, password, tipo_usuario, estado, fecha_creacion) VALUES (?, ?, ?, ?, ?, ?, 'activo', NOW())");
            $stmt->bind_param("ssssss", $dni, $nombres, $apellidos, $email, $password_hash, $tipo_usuario);
            
            if (!$stmt->execute()) {
                throw new Exception("Error al insertar usuario");
            }
            
            $usuario_id = $conexion->insert_id;
            
            // Si es estudiante y hay matrícula seleccionada
            $curso_matriculado = null;
            if ($tipo_usuario == 'estudiante' && !empty($_POST['unidad_didactica_id'])) {
                $unidad_didactica_id = $_POST['unidad_didactica_id'];
                
                // Obtener información del curso
                $stmt_curso = $conexion->prepare("SELECT nombre FROM unidades_didacticas WHERE id = ?");
                $stmt_curso->bind_param("i", $unidad_didactica_id);
                $stmt_curso->execute();
                $curso_result = $stmt_curso->get_result();
                if ($curso_row = $curso_result->fetch_assoc()) {
                    $curso_matriculado = $curso_row['nombre'];
                }
                
                // Insertar matrícula
                $stmt_matricula = $conexion->prepare("INSERT INTO matriculas (estudiante_id, unidad_didactica_id, fecha_matricula, estado) VALUES (?, ?, NOW(), 'activo')");
                $stmt_matricula->bind_param("ii", $usuario_id, $unidad_didactica_id);
                
                if (!$stmt_matricula->execute()) {
                    throw new Exception("Error al matricular estudiante");
                }
            }
            
            // Confirmar transacción
            $conexion->commit();
            
            // Log del registro exitoso
            error_log("Registro exitoso - DNI: $dni, Nombres: $nombres $apellidos, Tipo: $tipo_usuario");
            
            // Guardar información del registro exitoso
            $ultimo_registro = [
                'dni' => $dni,
                'nombres' => $nombres,
                'apellidos' => $apellidos,
                'tipo_usuario' => $tipo_usuario,
                'password' => $dni,
                'curso' => $curso_matriculado
            ];
            
            $registro_exitoso = true;
            $tipo_mensaje = "success";
            
            // Limpiar sesión
            unset($_SESSION['dni_data']);
            unset($_SESSION['dni_consultado']);
            
            // Limpiar variables para formulario
            $dni = $nombres = $apellidos = $email = '';
            
        } catch (Exception $e) {
            // Revertir transacción
            $conexion->rollback();
            $mensaje = "Error al registrar: " . $e->getMessage();
            $tipo_mensaje = "error";
            error_log("Error en registro: " . $e->getMessage());
        }
    } else {
        $mensaje = "Por favor corrija los siguientes errores:<br>• " . implode("<br>• ", $errores);
        $tipo_mensaje = "error";
    }
}

// ==================== OBTENER DATOS ====================
// Obtener programas de estudio
$programas = $conexion->query("SELECT * FROM programas_estudio WHERE estado = 'activo' ORDER BY nombre");

// Obtener unidades didácticas con información completa
$unidades_didacticas = $conexion->query("
    SELECT ud.*, pe.nombre as programa_nombre,
           (SELECT COUNT(*) FROM matriculas WHERE unidad_didactica_id = ud.id AND estado = 'activo') as estudiantes_matriculados
    FROM unidades_didacticas ud 
    JOIN programas_estudio pe ON ud.programa_id = pe.id 
    WHERE ud.estado = 'activo' 
    ORDER BY pe.nombre, ud.periodo_lectivo DESC, ud.nombre
");

// Obtener estadísticas
$stats = $conexion->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN tipo_usuario = 'estudiante' THEN 1 ELSE 0 END) as estudiantes,
        SUM(CASE WHEN tipo_usuario = 'docente' THEN 1 ELSE 0 END) as docentes
    FROM usuarios 
    WHERE estado = 'activo'
")->fetch_assoc();

// Últimos 5 registros
$ultimos_registros = $conexion->query("
    SELECT dni, CONCAT(apellidos, ', ', nombres) as nombre_completo, tipo_usuario, fecha_creacion 
    FROM usuarios 
    ORDER BY fecha_creacion DESC 
    LIMIT 5
");

// Prellenar formulario si hay datos de DNI consultado
$form_data = [
    'dni' => $_SESSION['dni_consultado'] ?? '',
    'nombres' => ($_SESSION['dni_data']['nombres'] ?? ''),
    'apellidos' => ($_SESSION['dni_data']['apellidos'] ?? '')
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Registro Académico</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a69bd;
            --secondary-color: #6a89cc;
            --success-color: #78e08f;
            --error-color: #e55039;
            --warning-color: #f6b93b;
            --text-dark: #2c3e50;
            --bg-gradient: linear-gradient(135deg, #0c1e70ff 0%, #0c43a1ff 100%);
            --card-bg: rgba(255, 255, 255, 0.98);
            --card-shadow: 0 30px 60px rgba(0, 0, 0, 0.3);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--text-dark);
        }
        
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        
        .particle {
            position: absolute;
            width: 8px;
            height: 8px;
            background: rgba(255, 255, 255, 0.4);
            border-radius: 50%;
            animation: float 15s infinite linear;
            opacity: 0;
        }
        
        @keyframes float {
            0% {
                transform: translateY(100vh) translateX(0) scale(0.5);
                opacity: 0;
            }
            10% {
                opacity: 0.8;
            }
            90% {
                opacity: 0.8;
            }
            100% {
                transform: translateY(-100px) translateX(100px) scale(1);
                opacity: 0;
            }
        }
        
        .container {
            width: 100%;
            max-width: 900px;
            position: relative;
            z-index: 1;
        }
        
        .main-card {
            background: var(--card-bg);
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            overflow: hidden;
            animation: slideUp 0.6s ease-out;
            backdrop-filter: blur(10px);
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            padding: 40px 30px;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: repeating-linear-gradient(
                45deg,
                transparent,
                transparent 10px,
                rgba(255,255,255,0.05) 10px,
                rgba(255,255,255,0.05) 20px
            );
            animation: slide 20s linear infinite;
        }
        
        @keyframes slide {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }
        
        .header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            position: relative;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .header p {
            font-size: 1rem;
            opacity: 0.9;
            position: relative;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .stat-item {
            text-align: center;
            padding: 25px;
            background: white;
            border-right: 1px solid #eee;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-item:last-child {
            border-right: none;
        }
        
        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            z-index: 1;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .form-container {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 0.9rem;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e1e8ed;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
            font-weight: 500;
            font-family: 'Poppins', sans-serif;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary-color);
            background: white;
            box-shadow: 0 0 0 3px rgba(74, 105, 189, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .dni-container {
            position: relative;
        }
        
        .dni-lookup-btn {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            z-index: 2;
        }
        
        .dni-lookup-btn:hover {
            background: var(--secondary-color);
            transform: translateY(-50%) scale(1.05);
        }
        
        .dni-lookup-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: translateY(-50%) scale(1);
        }
        
        .dni-feedback {
            margin-top: 8px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .btn-submit {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-submit:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(74, 105, 189, 0.3);
        }
        
        .btn-submit:active {
            transform: translateY(0);
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .alert.error {
            background: var(--error-color);
            color: white;
        }
        
        .alert.success {
            background: var(--success-color);
            color: var(--text-dark);
        }
        
        .success-explosion {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            max-width: 500px;
            width: 90%;
            text-align: center;
            animation: popIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }
        
        @keyframes popIn {
            0% {
                opacity: 0;
                transform: translate(-50%, -50%) scale(0.5);
            }
            80% {
                transform: translate(-50%, -50%) scale(1.1);
            }
            100% {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
        }
        
        .success-explosion h2 {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
        }
        
        .credential-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin: 15px 0;
        }
        
        .credential-item {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 8px;
            margin: 8px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .credential-label {
            font-weight: 500;
            opacity: 0.9;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .credential-value {
            font-family: 'Courier New', monospace;
            background: white;
            color: var(--primary-color);
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 1rem;
        }
        
        .btn-close-success {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 15px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin: 20px auto 0;
        }
        
        .btn-close-success:hover {
            background: var(--secondary-color);
            transform: scale(1.05);
        }
        
        .auto-filled {
            background: #f1f8e9 !important;
            border-color: var(--success-color) !important;
            position: relative;
        }
        
        .auto-filled::after {
            content: '🤖';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            opacity: 0.7;
            pointer-events: none;
        }
        
        .required {
            color: var(--error-color);
            font-weight: 700;
        }
        
        .info-text {
            background: var(--primary-color);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            margin-top: 20px;
            font-size: 0.9rem;
            line-height: 1.6;
        }
        
        .info-text strong {
            color: white;
        }
        
        #matricula-options {
            background: #f0f4f8;
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            border: 2px solid var(--primary-color);
            display: none;
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        #matricula-options h4 {
            color: var(--primary-color);
            margin-bottom: 15px;
            font-size: 1.2rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .recent-registrations {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
            margin-top: 20px;
        }
        
        .recent-title {
            font-size: 1rem;
            font-weight: 600;
            color: #495057;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .recent-item {
            background: white;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 3px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .recent-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 10px rgba(0,0,0,0.05);
        }
        
        .recent-name {
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .recent-type {
            background: var(--primary-color);
            color: white;
            padding: 3px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .form-group select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='%234a69bd'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 20px;
            padding-right: 45px;
        }
        
        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background: var(--primary-color);
            animation: confettiFall 3s linear forwards;
        }
        
        @keyframes confettiFall {
            0% {
                transform: translateY(-100vh) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotate(720deg);
                opacity: 0;
            }
        }
        
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            z-index: 9998;
            backdrop-filter: blur(5px);
        }
        
        .loading-overlay.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .loader {
            width: 80px;
            height: 80px;
            border: 5px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .stat-item {
                border-right: none;
                border-bottom: 1px solid #eee;
            }
            
            .stat-item:last-child {
                border-bottom: none;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .header {
                padding: 30px 20px;
            }
            
            .form-container {
                padding: 20px;
            }
            
            .dni-lookup-btn {
                position: static;
                transform: none;
                width: 100%;
                margin-top: 10px;
            }
            
            .dni-container {
                display: flex;
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Partículas de fondo -->
    <div class="particles">
        <?php for($i = 0; $i < 15; $i++): ?>
            <div class="particle" style="left: <?php echo rand(0, 100); ?>%; top: <?php echo rand(-20, 120); ?>%; animation-delay: <?php echo rand(0, 10); ?>s; animation-duration: <?php echo rand(10, 20); ?>s;"></div>
        <?php endfor; ?>
    </div>
    
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loader"></div>
    </div>
    
    <!-- Mensaje de éxito -->
    <?php if ($registro_exitoso && $ultimo_registro): ?>
        <div class="success-explosion" id="successExplosion">
            <h2><i class="fas fa-check-circle"></i> REGISTRO EXITOSO</h2>
            
            <div class="credential-card">
                <h4><i class="fas fa-id-card"></i> CREDENCIALES DE ACCESO</h4>
                <div class="credential-item">
                    <span class="credential-label"><i class="fas fa-user"></i> Usuario (DNI):</span>
                    <span class="credential-value"><?php echo $ultimo_registro['dni']; ?></span>
                </div>
                <div class="credential-item">
                    <span class="credential-label"><i class="fas fa-key"></i> Contraseña:</span>
                    <span class="credential-value"><?php echo $ultimo_registro['password']; ?></span>
                </div>
                <div class="credential-item">
                    <span class="credential-label"><i class="fas fa-signature"></i> Nombre:</span>
                    <span class="credential-value"><?php echo $ultimo_registro['apellidos'] . ', ' . $ultimo_registro['nombres']; ?></span>
                </div>
                <div class="credential-item">
                    <span class="credential-label"><i class="fas fa-user-tag"></i> Tipo:</span>
                    <span class="credential-value"><?php echo $ultimo_registro['tipo_usuario'] == 'estudiante' ? 'ESTUDIANTE' : 'DOCENTE'; ?></span>
                </div>
                <?php if ($ultimo_registro['curso']): ?>
                <div class="credential-item">
                    <span class="credential-label"><i class="fas fa-book"></i> Matriculado en:</span>
                    <span class="credential-value"><?php echo $ultimo_registro['curso']; ?></span>
                </div>
                <?php endif; ?>
            </div>
            
            <button class="btn-close-success" onclick="closeSuccessMessage()">
                <i class="fas fa-thumbs-up"></i> ENTENDIDO
            </button>
        </div>
        
        <script>
            // Crear confetti
            for(let i = 0; i < 50; i++) {
                setTimeout(() => {
                    const confetti = document.createElement('div');
                    confetti.className = 'confetti';
                    confetti.style.left = Math.random() * 100 + '%';
                    confetti.style.background = ['#4a69bd', '#6a89cc', '#e55039', '#78e08f', '#f6b93b'][Math.floor(Math.random() * 5)];
                    confetti.style.animationDelay = Math.random() * 2 + 's';
                    confetti.style.width = Math.random() * 10 + 5 + 'px';
                    confetti.style.height = Math.random() * 10 + 5 + 'px';
                    document.body.appendChild(confetti);
                    
                    setTimeout(() => confetti.remove(), 3000);
                }, i * 50);
            }
        </script>
    <?php endif; ?>
    
    <div class="container">
        <div class="main-card">
            <div class="header">
                <h1><i class="fas fa-user-plus"></i> REGISTRO ACADÉMICO</h1>
                <p>Sistema con Auto-completado DNI RENIEC integrado</p>
            </div>
            
            <!-- Estadísticas -->
            <div class="stats-container">
                <div class="stat-item">
                    <div class="stat-number"><?php echo $stats['total']; ?></div>
                    <div class="stat-label"><i class="fas fa-users"></i> Total Usuarios</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $stats['estudiantes']; ?></div>
                    <div class="stat-label"><i class="fas fa-graduation-cap"></i> Estudiantes</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $stats['docentes']; ?></div>
                    <div class="stat-label"><i class="fas fa-chalkboard-teacher"></i> Docentes</div>
                </div>
            </div>
            
            <div class="form-container">
                <?php if ($mensaje && !$registro_exitoso): ?>
                    <div class="alert <?php echo $tipo_mensaje; ?>">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $mensaje; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="registroForm" onsubmit="return validarFormulario()">
                    <input type="hidden" name="registrar" value="1">
                    
                    <div class="form-group">
                        <label><i class="fas fa-user-tag"></i> Tipo de Usuario <span class="required">*</span></label>
                        <select name="tipo_usuario" id="tipo_usuario" required onchange="toggleMatriculaOptions()">
                            <option value="">-- Seleccione el tipo de usuario --</option>
                            <option value="estudiante">ESTUDIANTE</option>
                            <option value="docente">DOCENTE</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-id-card"></i> DNI <span class="required">*</span></label>
                        <div class="dni-container">
                            <input type="text" 
                                   name="dni" 
                                   id="dni"
                                   maxlength="8" 
                                   pattern="[0-9]{8}" 
                                   placeholder="Ingrese exactamente 8 dígitos"
                                   value="<?php echo htmlspecialchars($form_data['dni']); ?>"
                                   required
                                   autocomplete="off"
                                   oninput="validateDNI(this)">
                            <button type="button" id="consultarBtn" class="dni-lookup-btn" onclick="consultarDNI()" disabled>
                                <i class="fas fa-search"></i> RENIEC
                            </button>
                        </div>
                        <div id="dni-feedback" class="dni-feedback"></div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-signature"></i> Nombres <span class="required">*</span></label>
                            <input type="text" 
                                   name="nombres" 
                                   id="nombres"
                                   placeholder="Ej: Juan Carlos"
                                   value="<?php echo htmlspecialchars($form_data['nombres']); ?>"
                                   class="<?php echo !empty($form_data['nombres']) ? 'auto-filled' : ''; ?>"
                                   required
                                   autocomplete="off">
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-signature"></i> Apellidos <span class="required">*</span></label>
                            <input type="text" 
                                   name="apellidos" 
                                   id="apellidos"
                                   placeholder="Ej: García López"
                                   value="<?php echo htmlspecialchars($form_data['apellidos']); ?>"
                                   class="<?php echo !empty($form_data['apellidos']) ? 'auto-filled' : ''; ?>"
                                   required
                                   autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email (Opcional)</label>
                        <input type="email" 
                               name="email" 
                               id="email"
                               placeholder="correo@ejemplo.com"
                               autocomplete="off">
                    </div>
                    
                    <!-- Opciones de matrícula para estudiantes -->
                    <div id="matricula-options">
                        <h4><i class="fas fa-book-open"></i> MATRICULAR EN CURSO</h4>
                        
                        <div class="form-group">
                            <label><i class="fas fa-graduation-cap"></i> Programa de Estudio</label>
                            <select name="programa_id" id="programa_id" onchange="filtrarUnidades()">
                                <option value="">-- Seleccione un programa (Opcional) --</option>
                                <?php 
                                if ($programas && $programas->num_rows > 0) {
                                    $programas->data_seek(0);
                                    while ($programa = $programas->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo $programa['id']; ?>">
                                        <?php echo htmlspecialchars($programa['nombre']); ?>
                                    </option>
                                <?php endwhile; } ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-book"></i> Unidad Didáctica</label>
                            <select name="unidad_didactica_id" id="unidad_didactica_id">
                                <option value="">-- Primero seleccione un programa --</option>
                            </select>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-user-plus"></i> REGISTRAR USUARIO
                    </button>
                </form>
                
                <div class="info-text">
                    <strong><i class="fas fa-info-circle"></i> INFORMACIÓN IMPORTANTE:</strong><br>
                    • La contraseña será automáticamente el <strong>NÚMERO DE DNI</strong><br>
                    • Haga clic en "RENIEC" para auto-completar nombres y apellidos<br>
                    • Sistema conectado a base de datos oficial RENIEC<br>
                    • Los estudiantes pueden matricularse en cursos al momento del registro<br>
                    • Todos los campos marcados con <span class="required">*</span> son obligatorios
                </div>
                
                <!-- Últimos registros -->
                <?php if ($ultimos_registros && $ultimos_registros->num_rows > 0): ?>
                <div class="recent-registrations">
                    <div class="recent-title"><i class="fas fa-history"></i> Últimos 5 Registros</div>
                    <?php while ($registro = $ultimos_registros->fetch_assoc()): ?>
                        <div class="recent-item">
                            <span class="recent-name"><?php echo htmlspecialchars($registro['nombre_completo']); ?></span>
                            <span class="recent-type"><?php echo $registro['tipo_usuario'] == 'estudiante' ? 'Estudiante' : 'Docente'; ?></span>
                        </div>
                    <?php endwhile; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        console.log('Sistema de Registro con Auto-completado DNI RENIEC iniciado');
        console.log('DNIs de prueba: 46027897, 71882580, 12345678, 87654321, 11111111, 22222222');
        
        // Datos de unidades didácticas
        const unidadesDidacticas = [
            <?php 
            if ($unidades_didacticas && $unidades_didacticas->num_rows > 0) {
                $unidades_didacticas->data_seek(0);
                while ($ud = $unidades_didacticas->fetch_assoc()): 
            ?>
            {
                id: <?php echo $ud['id']; ?>,
                nombre: "<?php echo addslashes($ud['nombre']); ?>",
                programa_id: <?php echo $ud['programa_id']; ?>,
                periodo: "<?php echo $ud['periodo_academico']; ?> - <?php echo $ud['periodo_lectivo']; ?>",
                matriculados: <?php echo $ud['estudiantes_matriculados']; ?>
            },
            <?php endwhile; } ?>
        ];
        
        function toggleMatriculaOptions() {
            const tipoUsuario = document.getElementById('tipo_usuario').value;
            const matriculaOptions = document.getElementById('matricula-options');
            
            if (tipoUsuario === 'estudiante') {
                matriculaOptions.style.display = 'block';
            } else {
                matriculaOptions.style.display = 'none';
                document.getElementById('programa_id').value = '';
                document.getElementById('unidad_didactica_id').value = '';
            }
        }
        
        function filtrarUnidades() {
            const programaId = document.getElementById('programa_id').value;
            const selectUnidades = document.getElementById('unidad_didactica_id');
            
            selectUnidades.innerHTML = '<option value="">-- Seleccione una unidad didáctica --</option>';
            
            if (programaId) {
                const unidadesFiltradas = unidadesDidacticas.filter(ud => ud.programa_id == programaId);
                
                unidadesFiltradas.forEach(ud => {
                    const option = document.createElement('option');
                    option.value = ud.id;
                    option.textContent = `${ud.nombre} (${ud.periodo}) - ${ud.matriculados} estudiantes`;
                    selectUnidades.appendChild(option);
                });
                
                if (unidadesFiltradas.length === 0) {
                    selectUnidades.innerHTML = '<option value="">No hay unidades disponibles</option>';
                }
            }
        }
        
        function validateDNI(input) {
            const dni = input.value.replace(/[^0-9]/g, '').slice(0, 8);
            input.value = dni;
            
            const feedback = document.getElementById('dni-feedback');
            const consultarBtn = document.getElementById('consultarBtn');
            
            if (dni.length === 8) {
                feedback.innerHTML = '<i class="fas fa-check-circle" style="color: #78e08f;"></i> DNI válido - Haga clic en RENIEC';
                feedback.style.color = '#78e08f';
                consultarBtn.disabled = false;
                consultarBtn.style.opacity = '1';
                input.style.borderColor = '#78e08f';
            } else if (dni.length > 0) {
                feedback.innerHTML = `<i class="fas fa-info-circle" style="color: #f6b93b;"></i> Faltan ${8 - dni.length} dígitos`;
                feedback.style.color = '#f6b93b';
                consultarBtn.disabled = true;
                consultarBtn.style.opacity = '0.5';
                input.style.borderColor = '#f6b93b';
            } else {
                feedback.innerHTML = '';
                consultarBtn.disabled = true;
                consultarBtn.style.opacity = '0.5';
                input.style.borderColor = '#e1e8ed';
            }
        }
        
        async function consultarDNI() {
            const dni = document.getElementById('dni').value;
            const consultarBtn = document.getElementById('consultarBtn');
            const feedback = document.getElementById('dni-feedback');
            const nombresInput = document.getElementById('nombres');
            const apellidosInput = document.getElementById('apellidos');
            
            if (dni.length !== 8) {
                alert('Ingrese un DNI válido de 8 dígitos');
                return;
            }
            
            // Deshabilitar botón y mostrar carga
            consultarBtn.disabled = true;
            consultarBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Consultando...';
            feedback.innerHTML = '<i class="fas fa-spinner fa-spin" style="color: #4a69bd;"></i> Consultando RENIEC...';
            feedback.style.color = '#4a69bd';
            
            // Deshabilitar campos de nombres
            nombresInput.disabled = true;
            apellidosInput.disabled = true;
            
            try {
                const formData = new FormData();
                formData.append('consultar_dni', '1');
                formData.append('dni', dni);
                
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                
                const data = await response.json();
                console.log('Respuesta consulta DNI:', data);
                
                if (data.success) {
                    // Llenar campos automáticamente
                    nombresInput.value = data.nombres;
                    apellidosInput.value = data.apellidos;
                    
                    // Marcar como auto-completados
                    nombresInput.classList.add('auto-filled');
                    apellidosInput.classList.add('auto-filled');
                    
                    // Feedback de éxito
                    feedback.innerHTML = `<i class="fas fa-check-circle" style="color: #78e08f;"></i> Datos encontrados (${data.service})`;
                    feedback.style.color = '#78e08f';
                    
                    // Efecto visual
                    [nombresInput, apellidosInput].forEach(input => {
                        input.style.transform = 'scale(1.02)';
                        setTimeout(() => {
                            input.style.transform = 'scale(1)';
                        }, 200);
                    });
                    
                    // Alerta de éxito
                    setTimeout(() => {
                        alert(`✅ Datos encontrados en ${data.service}:\n\n` +
                              `Nombres: ${data.nombres}\n` +
                              `Apellidos: ${data.apellidos}\n\n` +
                              `Los campos se han llenado automáticamente.`);
                    }, 100);
                    
                } else {
                    // DNI no encontrado
                    feedback.innerHTML = '<i class="fas fa-exclamation-triangle" style="color: #f6b93b;"></i> DNI no encontrado. Complete manualmente.';
                    feedback.style.color = '#f6b93b';
                    
                    // Limpiar campos si tenían datos previos
                    if (nombresInput.classList.contains('auto-filled')) {
                        nombresInput.value = '';
                        apellidosInput.value = '';
                        nombresInput.classList.remove('auto-filled');
                        apellidosInput.classList.remove('auto-filled');
                    }
                    
                    // Enfocar en nombres
                    nombresInput.focus();
                    
                    alert('⚠️ DNI no encontrado en la base de datos.\n' +
                          'Por favor, complete los nombres y apellidos manualmente.');
                }
                
            } catch (error) {
                console.error('Error al consultar DNI:', error);
                
                feedback.innerHTML = '<i class="fas fa-times-circle" style="color: #e55039;"></i> Error de conexión. Complete manualmente.';
                feedback.style.color = '#e55039';
                
                alert('❌ Error de conexión.\n' +
                      'Por favor, complete los datos manualmente.\n\n' +
                      'Error: ' + error.message);
                      
            } finally {
                // Restaurar botón y campos
                consultarBtn.disabled = false;
                consultarBtn.innerHTML = '<i class="fas fa-search"></i> RENIEC';
                nombresInput.disabled = false;
                apellidosInput.disabled = false;
            }
        }
        
        function validarFormulario() {
            const dni = document.getElementById('dni').value;
            const nombres = document.getElementById('nombres').value;
            const apellidos = document.getElementById('apellidos').value;
            const tipoUsuario = document.getElementById('tipo_usuario').value;
            
            // Validar DNI
            if (!/^[0-9]{8}$/.test(dni)) {
                alert('El DNI debe tener exactamente 8 dígitos numéricos');
                document.getElementById('dni').focus();
                return false;
            }
            
            // Validar tipo de usuario
            if (!tipoUsuario) {
                alert('Debe seleccionar un tipo de usuario');
                document.getElementById('tipo_usuario').focus();
                return false;
            }
            
            // Validar nombres
            if (!nombres.trim()) {
                alert('Los nombres son obligatorios');
                document.getElementById('nombres').focus();
                return false;
            }
            
            // Validar apellidos
            if (!apellidos.trim()) {
                alert('Los apellidos son obligatorios');
                document.getElementById('apellidos').focus();
                return false;
            }
            
            // Mostrar loading
            document.getElementById('loadingOverlay').classList.add('active');
            
            return true;
        }
        
        function closeSuccessMessage() {
            const successExplosion = document.getElementById('successExplosion');
            if (successExplosion) {
                successExplosion.style.animation = 'popIn 0.5s reverse';
                setTimeout(() => {
                    successExplosion.remove();
                    // Limpiar formulario
                    document.getElementById('registroForm').reset();
                    document.getElementById('dni-feedback').innerHTML = '';
                    document.getElementById('consultarBtn').disabled = true;
                    document.getElementById('consultarBtn').style.opacity = '0.5';
                    document.getElementById('matricula-options').style.display = 'none';
                }, 500);
            }
        }
        
        // Auto-cerrar mensaje de éxito después de 15 segundos
        setTimeout(() => {
            if (document.getElementById('successExplosion')) {
                closeSuccessMessage();
            }
        }, 15000);
        
        // Permitir edición manual de campos auto-completados
        document.getElementById('nombres').addEventListener('input', function() {
            this.classList.remove('auto-filled');
        });
        
        document.getElementById('apellidos').addEventListener('input', function() {
            this.classList.remove('auto-filled');
        });
        
        // Inicializar validación DNI si hay valor
        const dniInput = document.getElementById('dni');
        if (dniInput.value) {
            validateDNI(dniInput);
        }
        
        // Efectos de hover para elementos del formulario
        document.querySelectorAll('input, select').forEach(element => {
            element.addEventListener('mouseenter', function() {
                if (!this.disabled) {
                    this.style.transform = 'scale(1.02)';
                }
            });
            
            element.addEventListener('mouseleave', function() {
                if (this !== document.activeElement) {
                    this.style.transform = 'scale(1)';
                }
            });
        });
        
        // Animación de entrada para elementos del formulario
        const formGroups = document.querySelectorAll('.form-group');
        formGroups.forEach((group, index) => {
            group.style.opacity = '0';
            group.style.transform = 'translateY(20px)';
            setTimeout(() => {
                group.style.transition = 'all 0.5s ease';
                group.style.opacity = '1';
                group.style.transform = 'translateY(0)';
            }, index * 100);
        });
    </script>
</body>
</html>