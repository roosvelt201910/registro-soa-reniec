<?php
// admin/manage_users.php - Sistema de Gestión de Usuarios Ultra Mejorado
session_start();

// ==================== CONFIGURACIÓN DE BASE DE DATOS ====================
$db_host = 'localhost';
$db_user = 'iespaltohuallaga_user_regaux';
$db_pass = ')wBRCeID[ldb%b^K';
$db_name = 'iespaltohuallaga_regauxiliar_bd';

// Crear conexión
$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecer charset UTF-8
$conexion->set_charset("utf8mb4");
date_default_timezone_set('America/Lima');

// ==================== VERIFICACIÓN DE PERMISOS ====================
if (!isset($_SESSION['user_id']) || $_SESSION['tipo_usuario'] != 'super_admin') {
    // Para pruebas - quitar en producción
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['user_id'] = 1;
        $_SESSION['tipo_usuario'] = 'super_admin';
        $_SESSION['nombres'] = 'Super';
        $_SESSION['apellidos'] = 'Administrador';
    }
}

$message = '';
$messageType = '';

// ==================== FUNCIÓN PARA REGISTRAR LOGS ====================
function registrarLog($conexion, $usuario_id, $accion, $detalles) {
    $stmt = $conexion->prepare("INSERT INTO logs_sistema (usuario_id, accion, detalles, fecha_registro, ip_address) VALUES (?, ?, ?, NOW(), ?)");
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt->bind_param("isss", $usuario_id, $accion, $detalles, $ip);
    $stmt->execute();
}

// ==================== FUNCIÓN PARA VALIDAR CONTRASEÑA ====================
function validarContrasena($password) {
    $errores = [];
    
    if (strlen($password) < 8) {
        $errores[] = "La contraseña debe tener al menos 8 caracteres";
    }
    
    if (!preg_match('/[A-Z]/', $password)) {
        $errores[] = "La contraseña debe contener al menos una letra mayúscula";
    }
    
    if (!preg_match('/[a-z]/', $password)) {
        $errores[] = "La contraseña debe contener al menos una letra minúscula";
    }
    
    if (!preg_match('/[0-9]/', $password)) {
        $errores[] = "La contraseña debe contener al menos un número";
    }
    
    return $errores;
}

// ==================== PROCESAR ACCIONES AJAX ====================
if (isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    
    switch($_POST['ajax_action']) {
        case 'get_user':
            $user_id = intval($_POST['user_id']);
            $stmt = $conexion->prepare("SELECT id, dni, nombres, apellidos, email, tipo_usuario, estado FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            echo json_encode($user);
            exit;
            
        case 'update_user':
            $user_id = intval($_POST['user_id']);
            $dni = trim($_POST['dni']);
            $nombres = trim($_POST['nombres']);
            $apellidos = trim($_POST['apellidos']);
            $email = trim($_POST['email']);
            $tipo_usuario = $_POST['tipo_usuario'];
            
            // Validaciones
            if (strlen($dni) != 8 || !is_numeric($dni)) {
                echo json_encode(['success' => false, 'message' => 'El DNI debe tener exactamente 8 dígitos']);
                exit;
            }
            
            // Verificar si el DNI ya existe en otro usuario
            $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE dni = ? AND id != ?");
            $stmt->bind_param("si", $dni, $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                echo json_encode(['success' => false, 'message' => 'Ya existe otro usuario con ese DNI']);
                exit;
            }
            
            // Actualizar usuario
            $stmt = $conexion->prepare("UPDATE usuarios SET dni = ?, nombres = ?, apellidos = ?, email = ?, tipo_usuario = ? WHERE id = ?");
            $stmt->bind_param("sssssi", $dni, $nombres, $apellidos, $email, $tipo_usuario, $user_id);
            
            if ($stmt->execute()) {
                registrarLog($conexion, $_SESSION['user_id'], 'ACTUALIZAR_USUARIO', "Usuario ID: $user_id actualizado");
                echo json_encode(['success' => true, 'message' => 'Usuario actualizado exitosamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar usuario: ' . $conexion->error]);
            }
            exit;
            
        case 'change_password':
            $user_id = intval($_POST['user_id']);
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            // Validaciones
            if ($new_password !== $confirm_password) {
                echo json_encode(['success' => false, 'message' => 'Las contraseñas no coinciden']);
                exit;
            }
            
            $errores = validarContrasena($new_password);
            if (!empty($errores)) {
                echo json_encode(['success' => false, 'message' => implode('; ', $errores)]);
                exit;
            }
            
            // Cambiar contraseña
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conexion->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $password_hash, $user_id);
            
            if ($stmt->execute()) {
                registrarLog($conexion, $_SESSION['user_id'], 'CAMBIAR_CONTRASEÑA', "Contraseña cambiada para usuario ID: $user_id");
                echo json_encode(['success' => true, 'message' => 'Contraseña actualizada exitosamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar la contraseña']);
            }
            exit;
            
        case 'toggle_status':
            $user_id = intval($_POST['user_id']);
            
            // No permitir desactivar el super admin principal
            if ($user_id == 1) {
                echo json_encode(['success' => false, 'message' => 'No se puede desactivar el Super Administrador principal']);
                exit;
            }
            
            // Obtener estado actual
            $stmt = $conexion->prepare("SELECT estado, nombres, apellidos FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            $new_status = ($user['estado'] == 'activo') ? 'inactivo' : 'activo';
            
            $stmt = $conexion->prepare("UPDATE usuarios SET estado = ? WHERE id = ?");
            $stmt->bind_param("si", $new_status, $user_id);
            
            if ($stmt->execute()) {
                $nombre_completo = $user['nombres'] . ' ' . $user['apellidos'];
                registrarLog($conexion, $_SESSION['user_id'], 'CAMBIAR_ESTADO_USUARIO', "Estado cambiado a '$new_status' para: $nombre_completo");
                echo json_encode(['success' => true, 'new_status' => $new_status]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al cambiar el estado']);
            }
            exit;
            
        case 'reset_password':
            $user_id = intval($_POST['user_id']);
            
            // Obtener DNI del usuario
            $stmt = $conexion->prepare("SELECT dni, nombres, apellidos FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            // Resetear contraseña al DNI
            $new_password = password_hash($user['dni'], PASSWORD_DEFAULT);
            
            $stmt = $conexion->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $new_password, $user_id);
            
            if ($stmt->execute()) {
                $nombre_completo = $user['nombres'] . ' ' . $user['apellidos'];
                registrarLog($conexion, $_SESSION['user_id'], 'RESETEAR_CONTRASEÑA', "Contraseña reseteada al DNI para: $nombre_completo");
                echo json_encode(['success' => true, 'message' => 'Contraseña reseteada al DNI del usuario']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al resetear la contraseña']);
            }
            exit;
            
        case 'delete_user':
            $user_id = intval($_POST['user_id']);
            
            // Validaciones de seguridad
            if ($user_id == 1) {
                echo json_encode(['success' => false, 'message' => 'No se puede eliminar el Super Administrador principal']);
                exit;
            }
            
            if ($user_id == $_SESSION['user_id']) {
                echo json_encode(['success' => false, 'message' => 'No puede eliminar su propio usuario']);
                exit;
            }
            
            // Obtener información del usuario antes de eliminar
            $stmt = $conexion->prepare("SELECT nombres, apellidos FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $nombre_completo = $user['nombres'] . ' ' . $user['apellidos'];
            
            // Iniciar transacción
            $conexion->begin_transaction();
            
            try {
                // Eliminar registros relacionados en orden
                $conexion->query("DELETE FROM asistencias WHERE estudiante_id = $user_id");
                $conexion->query("DELETE FROM evaluaciones_sesion WHERE estudiante_id = $user_id");
                $conexion->query("DELETE FROM matriculas WHERE estudiante_id = $user_id");
                
                // Actualizar unidades didácticas (no eliminar, solo cambiar docente)
                $conexion->query("UPDATE unidades_didacticas SET docente_id = 1 WHERE docente_id = $user_id");
                
                // Eliminar el usuario
                $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                
                $conexion->commit();
                registrarLog($conexion, $_SESSION['user_id'], 'ELIMINAR_USUARIO', "Usuario eliminado: $nombre_completo");
                echo json_encode(['success' => true, 'message' => 'Usuario eliminado exitosamente']);
            } catch (Exception $e) {
                $conexion->rollback();
                echo json_encode(['success' => false, 'message' => 'Error al eliminar usuario: ' . $e->getMessage()]);
            }
            exit;
            
        case 'get_user_stats':
            $user_id = intval($_POST['user_id']);
            
            // Obtener estadísticas del usuario
            $stats = [];
            
            // Si es estudiante
            $stmt = $conexion->prepare("SELECT COUNT(*) as cursos_matriculados FROM matriculas WHERE estudiante_id = ? AND estado = 'activo'");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $stats['cursos_matriculados'] = $result->fetch_assoc()['cursos_matriculados'];
            
            // Si es docente
            $stmt = $conexion->prepare("SELECT COUNT(*) as cursos_asignados FROM unidades_didacticas WHERE docente_id = ? AND estado = 'activo'");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $stats['cursos_asignados'] = $result->fetch_assoc()['cursos_asignados'];
            
            echo json_encode($stats);
            exit;
    }
}

// ==================== PROCESAR CREACIÓN DE USUARIO ====================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'create_user') {
    $dni = trim($_POST['dni']);
    $nombres = trim($_POST['nombres']);
    $apellidos = trim($_POST['apellidos']);
    $email = trim($_POST['email']);
    $tipo_usuario = $_POST['tipo_usuario'];
    $password_personalizada = isset($_POST['password_personalizada']) && $_POST['password_personalizada'] == '1';
    $custom_password = trim($_POST['custom_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    
    // Validaciones
    if (strlen($dni) != 8 || !is_numeric($dni)) {
        $message = '❌ El DNI debe tener exactamente 8 dígitos numéricos.';
        $messageType = 'error';
    } elseif (empty($nombres) || empty($apellidos)) {
        $message = '❌ Los nombres y apellidos son obligatorios.';
        $messageType = 'error';
    } elseif ($password_personalizada && ($custom_password !== $confirm_password)) {
        $message = '❌ Las contraseñas no coinciden.';
        $messageType = 'error';
    } else {
        // Validar contraseña personalizada si se especificó
        if ($password_personalizada) {
            $errores = validarContrasena($custom_password);
            if (!empty($errores)) {
                $message = '❌ ' . implode('. ', $errores);
                $messageType = 'error';
            }
        }
        
        if (empty($message)) {
            // Verificar si el DNI ya existe
            $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE dni = ?");
            $stmt->bind_param("s", $dni);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $message = '❌ Ya existe un usuario con ese DNI.';
                $messageType = 'error';
            } else {
                // Crear usuario
                $password_final = $password_personalizada ? $custom_password : $dni;
                $password_hash = password_hash($password_final, PASSWORD_DEFAULT);
                
                $stmt = $conexion->prepare("INSERT INTO usuarios (dni, nombres, apellidos, email, password, tipo_usuario, estado, fecha_creacion) VALUES (?, ?, ?, ?, ?, ?, 'activo', NOW())");
                $stmt->bind_param("ssssss", $dni, $nombres, $apellidos, $email, $password_hash, $tipo_usuario);
                
                if ($stmt->execute()) {
                    $nombre_completo = $apellidos . ', ' . $nombres;
                    registrarLog($conexion, $_SESSION['user_id'], 'CREAR_USUARIO', "Usuario creado: $nombre_completo ($dni)");
                    
                    $password_msg = $password_personalizada ? 'la contraseña personalizada' : $dni;
                    $message = '✅ Usuario creado exitosamente. Contraseña: ' . $password_msg;
                    $messageType = 'success';
                } else {
                    $message = '❌ Error al crear el usuario: ' . $conexion->error;
                    $messageType = 'error';
                }
            }
        }
    }
}

// ==================== CREAR TABLA DE LOGS SI NO EXISTE ====================
$conexion->query("CREATE TABLE IF NOT EXISTS logs_sistema (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    accion VARCHAR(100) NOT NULL,
    detalles TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    INDEX(usuario_id),
    INDEX(fecha_registro),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
)");

// ==================== OBTENER LISTA DE USUARIOS ====================
$query = "SELECT u.*, 
          (SELECT COUNT(*) FROM matriculas WHERE estudiante_id = u.id AND estado = 'activo') as cursos_matriculados,
          (SELECT COUNT(*) FROM unidades_didacticas WHERE docente_id = u.id AND estado = 'activo') as cursos_asignados
          FROM usuarios u 
          ORDER BY u.fecha_creacion DESC";
$result = $conexion->query($query);
$usuarios = [];
while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
}

// Estadísticas
$total_users = count(array_filter($usuarios, function($u) { return $u['estado'] == 'activo'; }));
$docentes = count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'docente' && $u['estado'] == 'activo'; }));
$estudiantes = count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'estudiante' && $u['estado'] == 'activo'; }));
$admins = count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'super_admin' && $u['estado'] == 'activo'; }));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚀 Gestión de Usuarios - Sistema Académico Ultra</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }
        
        /* Header Ultra */
        .header {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
            padding: 1.5rem 2rem;
        }
        
        .header h1 {
            font-size: 2em;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 800;
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        /* Stats Grid Ultra */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
            animation: fadeInUp 0.6s ease;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2, #667eea);
            background-size: 200% 100%;
            animation: shimmer 3s infinite;
        }
        
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        
        .stat-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
        }
        
        .stat-icon {
            font-size: 3em;
            margin-bottom: 15px;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: 800;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 1em;
            color: #6c757d;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Card Ultra */
        .card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        
        .card h2 {
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 3px solid #f0f0f0;
            position: relative;
        }
        
        .card h2::after {
            content: '';
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            animation: expand 1s ease;
        }
        
        @keyframes expand {
            from { width: 0; }
            to { width: 100px; }
        }
        
        /* Form Ultra */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 0.95em;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e1e8ed;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: #f8f9fa;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: auto;
            transform: scale(1.2);
        }
        
        .password-strength {
            margin-top: 5px;
            font-size: 12px;
        }
        
        .strength-weak { color: #dc3545; }
        .strength-medium { color: #ffc107; }
        .strength-strong { color: #28a745; }
        
        /* Buttons Ultra */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 15px;
            font-weight: 600;
            margin-right: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn:hover::before {
            width: 300%;
            height: 300%;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #00c853 0%, #00e676 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(0, 200, 83, 0.3);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ff5252 0%, #ff1744 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(255, 23, 68, 0.3);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #ffb300 0%, #ffc107 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.3);
        }
        
        .btn-info {
            background: linear-gradient(135deg, #00bcd4 0%, #00acc1 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(0, 188, 212, 0.3);
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }
        
        /* Table Ultra */
        .table-container {
            overflow-x: auto;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            position: relative;
        }
        
        .search-bar {
            margin-bottom: 20px;
            position: relative;
        }
        
        .search-bar input {
            width: 100%;
            padding: 14px 20px 14px 50px;
            border: 2px solid #e1e8ed;
            border-radius: 50px;
            font-size: 15px;
            transition: all 0.3s;
            background: white;
        }
        
        .search-bar input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .search-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .users-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .users-table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .users-table th {
            padding: 18px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .users-table th:first-child {
            border-top-left-radius: 15px;
        }
        
        .users-table th:last-child {
            border-top-right-radius: 15px;
        }
        
        .users-table td {
            padding: 16px 18px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }
        
        .users-table tbody tr {
            background: white;
            transition: all 0.3s;
        }
        
        .users-table tbody tr:hover {
            background: #f8f9fa;
            transform: scale(1.01);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        /* Badges Ultra */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            display: inline-block;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }
        
        .badge-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }
        
        .badge-primary {
            background: linear-gradient(135deg, #cfe2ff 0%, #b6d4fe 100%);
            color: #084298;
        }
        
        .badge-warning {
            background: linear-gradient(135deg, #fff3cd 0%, #ffe69c 100%);
            color: #664d03;
        }
        
        .badge-info {
            background: linear-gradient(135deg, #cff4fc 0%, #b6effb 100%);
            color: #055160;
        }
        
        /* Alert Messages */
        .alert {
            padding: 20px 25px;
            border-radius: 15px;
            margin-bottom: 25px;
            position: relative;
            animation: slideInAlert 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        @keyframes slideInAlert {
            from {
                opacity: 0;
                transform: translateX(-50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateX(0) scale(1);
            }
        }
        
        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            border-left: 5px solid #28a745;
        }
        
        .alert-error {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
            border-left: 5px solid #dc3545;
        }
        
        .alert-icon {
            font-size: 2em;
        }
        
        /* Modal Ultra */
        .modal {
            display: none;
            position: fixed;
            z-index: 10000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            animation: fadeInModal 0.3s ease;
        }
        
        @keyframes fadeInModal {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .modal-content {
            background: white;
            margin: 50px auto;
            padding: 0;
            border-radius: 20px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: slideUpModal 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            overflow: hidden;
        }
        
        @keyframes slideUpModal {
            from {
                transform: translateY(100px) scale(0.9);
                opacity: 0;
            }
            to {
                transform: translateY(0) scale(1);
                opacity: 1;
            }
        }
        
        .modal-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            font-size: 1.5em;
            font-weight: 700;
        }
        
        .close {
            color: white;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s;
            background: none;
            border: none;
        }
        
        .close:hover {
            transform: rotate(90deg);
        }
        
        .modal-body {
            padding: 30px;
        }
        
        /* Actions Dropdown */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        
        .dropdown-toggle {
            cursor: pointer;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 220px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.3);
            z-index: 999999;
            border-radius: 15px;
            overflow: hidden;
            margin-top: 5px;
            border: 2px solid rgba(102, 126, 234, 0.1);
            animation: dropdownSlide 0.3s ease;
        }
        
        @keyframes dropdownSlide {
            from {
                opacity: 0;
                transform: translateY(-10px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        .dropdown.active .dropdown-content {
            display: block;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 14px 20px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }
        
        .dropdown-content a::before {
            content: '';
            position: absolute;
            left: -100%;
            top: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: left 0.3s;
            z-index: -1;
        }
        
        .dropdown-content a:hover::before {
            left: 0;
        }
        
        .dropdown-content a:hover {
            color: white;
            padding-left: 30px;
        }
        
        .dropdown-content a:not(:last-child) {
            border-bottom: 1px solid #f0f0f0;
        }
        
        /* Loading Spinner */
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            vertical-align: middle;
            margin-left: 10px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 0 1rem;
            }
            
            .header-content {
                flex-direction: column;
                gap: 15px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .users-table {
                font-size: 12px;
            }
            
            .btn {
                font-size: 12px;
                padding: 8px 16px;
            }
        }
        
        /* Floating Action Button */
        .fab {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 99;
        }
        
        .fab:hover {
            transform: scale(1.1) rotate(90deg);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.5);
        }
        
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>🚀 Gestión de Usuarios Ultra</h1>
            <div>
                <span style="margin-right: 20px; font-weight: 600;">
                    👤 <?php echo $_SESSION['apellidos'] . ', ' . $_SESSION['nombres']; ?>
                </span>
                <a href="../dashboard.php" class="btn btn-primary">
                    ← Volver al Dashboard
                </a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <span class="alert-icon"><?php echo $messageType == 'success' ? '✅' : '❌'; ?></span>
                <span><?php echo $message; ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div class="stat-label">Usuarios Activos</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍🏫</div>
                <div class="stat-number"><?php echo $docentes; ?></div>
                <div class="stat-label">Docentes</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍🎓</div>
                <div class="stat-number"><?php echo $estudiantes; ?></div>
                <div class="stat-label">Estudiantes</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍💼</div>
                <div class="stat-number"><?php echo $admins; ?></div>
                <div class="stat-label">Administradores</div>
            </div>
        </div>
        
        <!-- Formulario para crear usuario -->
        <div class="card">
            <h2>✨ Crear Nuevo Usuario</h2>
            <form method="POST" id="createUserForm">
                <input type="hidden" name="action" value="create_user">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="dni">DNI <span style="color: #ff1744;">*</span></label>
                        <input type="text" 
                               id="dni" 
                               name="dni" 
                               maxlength="8" 
                               pattern="[0-9]{8}" 
                               placeholder="Ej: 12345678"
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo_usuario">Tipo de Usuario <span style="color: #ff1744;">*</span></label>
                        <select name="tipo_usuario" id="tipo_usuario" required>
                            <option value="">Seleccione...</option>
                            <option value="super_admin">👨‍💼 Super Administrador</option>
                            <option value="docente">👨‍🏫 Docente</option>
                            <option value="estudiante">👨‍🎓 Estudiante</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombres">Nombres <span style="color: #ff1744;">*</span></label>
                        <input type="text" 
                               id="nombres" 
                               name="nombres" 
                               placeholder="Ej: Juan Carlos"
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="apellidos">Apellidos <span style="color: #ff1744;">*</span></label>
                        <input type="text" 
                               id="apellidos" 
                               name="apellidos" 
                               placeholder="Ej: García López"
                               required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               placeholder="usuario@ejemplo.com">
                    </div>
                </div>
                
                <!-- Opción de contraseña personalizada -->
                <div class="checkbox-group">
                    <input type="checkbox" id="password_personalizada" name="password_personalizada" value="1" onchange="toggleCustomPassword()">
                    <label for="password_personalizada">🔐 Establecer contraseña personalizada (en lugar del DNI)</label>
                </div>
                
                <div id="custom_password_fields" class="hidden">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="custom_password">Nueva Contraseña</label>
                            <input type="password" 
                                   id="custom_password" 
                                   name="custom_password" 
                                   placeholder="Mínimo 8 caracteres, incluir mayúsculas, minúsculas y números"
                                   oninput="checkPasswordStrength()">
                            <div id="password_strength" class="password-strength"></div>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirmar Contraseña</label>
                            <input type="password" 
                                   id="confirm_password" 
                                   name="confirm_password" 
                                   placeholder="Repetir la contraseña">
                        </div>
                    </div>
                </div>
                
                <div style="background: linear-gradient(135deg, #fff3cd 0%, #ffe69c 100%); padding: 20px; border-radius: 15px; border-left: 5px solid #ffc107; margin-bottom: 25px;">
                    <p style="margin: 0; color: #664d03; font-weight: 600;">
                        <strong>📌 Nota:</strong> 
                        <span id="password_note">La contraseña será el número de DNI del usuario.</span>
                        El usuario deberá cambiarla en su primer inicio de sesión.
                    </p>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <span>CREAR USUARIO</span>
                </button>
            </form>
        </div>
        
        <!-- Lista de usuarios -->
        <div class="card">
            <h2>📋 Lista de Usuarios Registrados</h2>
            
            <div class="search-bar">
                <span class="search-icon">🔍</span>
                <input type="text" id="searchInput" placeholder="Buscar por nombre, DNI, email..." onkeyup="filterTable()">
            </div>
            
            <?php if (empty($usuarios)): ?>
                <p style="text-align: center; padding: 40px; color: #6c757d;">No hay usuarios registrados en el sistema.</p>
            <?php else: ?>
                <div class="table-container">
                    <table class="users-table" id="usersTable">
                        <thead>
                            <tr>
                                <th>DNI</th>
                                <th>Nombre Completo</th>
                                <th>Email</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                                <th>Cursos</th>
                                <th>Registro</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($usuarios as $usuario): ?>
                                <tr data-user-id="<?php echo $usuario['id']; ?>">
                                    <td><strong><?php echo htmlspecialchars($usuario['dni']); ?></strong></td>
                                    <td>
                                        <div style="font-weight: 600;"><?php echo htmlspecialchars($usuario['apellidos'] . ', ' . $usuario['nombres']); ?></div>
                                    </td>
                                    <td><?php echo htmlspecialchars($usuario['email'] ?: 'No especificado'); ?></td>
                                    <td>
                                        <?php
                                        $tipo_badge = '';
                                        $tipo_icon = '';
                                        switch($usuario['tipo_usuario']) {
                                            case 'super_admin':
                                                $tipo_badge = 'badge-primary';
                                                $tipo_icon = '👨‍💼';
                                                break;
                                            case 'docente':
                                                $tipo_badge = 'badge-info';
                                                $tipo_icon = '👨‍🏫';
                                                break;
                                            case 'estudiante':
                                                $tipo_badge = 'badge-success';
                                                $tipo_icon = '👨‍🎓';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?php echo $tipo_badge; ?>">
                                            <?php echo $tipo_icon . ' ' . ucfirst(str_replace('_', ' ', $usuario['tipo_usuario'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $usuario['estado'] == 'activo' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo $usuario['estado'] == 'activo' ? '✅ Activo' : '❌ Inactivo'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($usuario['tipo_usuario'] == 'estudiante'): ?>
                                            <span class="badge badge-warning"><?php echo $usuario['cursos_matriculados']; ?> cursos</span>
                                        <?php elseif ($usuario['tipo_usuario'] == 'docente'): ?>
                                            <span class="badge badge-warning"><?php echo $usuario['cursos_asignados']; ?> cursos</span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($usuario['fecha_creacion'])); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-primary btn-sm dropdown-toggle" onclick="toggleDropdown(this)">
                                                ⚙️ Acciones ▼
                                            </button>
                                            <div class="dropdown-content">
                                                <a href="#" onclick="editUser(<?php echo $usuario['id']; ?>)">
                                                    ✏️ Editar Usuario
                                                </a>
                                                <a href="#" onclick="changePassword(<?php echo $usuario['id']; ?>)">
                                                    🔑 Cambiar Contraseña
                                                </a>
                                                <a href="#" onclick="resetPassword(<?php echo $usuario['id']; ?>)">
                                                    🔐 Resetear al DNI
                                                </a>
                                                <?php if ($usuario['id'] != $_SESSION['user_id'] && $usuario['id'] != 1): ?>
                                                    <a href="#" onclick="toggleUserStatus(<?php echo $usuario['id']; ?>)">
                                                        <?php echo $usuario['estado'] == 'activo' ? '⏸️ Desactivar Usuario' : '▶️ Activar Usuario'; ?>
                                                    </a>
                                                    <a href="#" onclick="deleteUser(<?php echo $usuario['id']; ?>)" style="color: #dc3545;">
                                                        🗑️ Eliminar Usuario
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal para editar usuario -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>✏️ Editar Usuario</h2>
                <button class="close" onclick="closeModal('editModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <input type="hidden" id="edit_user_id">
                    
                    <div class="form-group">
                        <label>DNI</label>
                        <input type="text" id="edit_dni" maxlength="8" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Nombres</label>
                        <input type="text" id="edit_nombres" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Apellidos</label>
                        <input type="text" id="edit_apellidos" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="edit_email">
                    </div>
                    
                    <div class="form-group">
                        <label>Tipo de Usuario</label>
                        <select id="edit_tipo_usuario" required>
                            <option value="super_admin">👨‍💼 Super Administrador</option>
                            <option value="docente">👨‍🏫 Docente</option>
                            <option value="estudiante">👨‍🎓 Estudiante</option>
                        </select>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button type="submit" class="btn btn-success">💾 Guardar Cambios</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal('editModal')">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Modal para cambiar contraseña -->
    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>🔑 Cambiar Contraseña</h2>
                <button class="close" onclick="closeModal('passwordModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="changePasswordForm">
                    <input type="hidden" id="password_user_id">
                    
                    <div class="form-group">
                        <label>Nueva Contraseña</label>
                        <input type="password" 
                               id="new_password" 
                               placeholder="Mínimo 8 caracteres, incluir mayúsculas, minúsculas y números"
                               oninput="checkPasswordStrengthModal()"
                               required>
                        <div id="password_strength_modal" class="password-strength"></div>
                    </div>
                    
                    <div class="form-group">
                        <label>Confirmar Nueva Contraseña</label>
                        <input type="password" 
                               id="confirm_new_password" 
                               placeholder="Repetir la nueva contraseña"
                               required>
                    </div>
                    
                    <div style="background: linear-gradient(135deg, #cff4fc 0%, #b6effb 100%); padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                        <p style="margin: 0; color: #055160; font-size: 14px;">
                            <strong>📋 Requisitos de la contraseña:</strong><br>
                            • Al menos 8 caracteres<br>
                            • Al menos una letra mayúscula<br>
                            • Al menos una letra minúscula<br>
                            • Al menos un número
                        </p>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button type="submit" class="btn btn-success">🔑 Cambiar Contraseña</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal('passwordModal')">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Floating Action Button -->
    <div class="fab" onclick="scrollToTop()">
        ↑
    </div>
    
    <script>
        // Toggle custom password fields
        function toggleCustomPassword() {
            const checkbox = document.getElementById('password_personalizada');
            const fields = document.getElementById('custom_password_fields');
            const note = document.getElementById('password_note');
            
            if (checkbox.checked) {
                fields.classList.remove('hidden');
                note.textContent = 'Se establecerá la contraseña personalizada especificada.';
                document.getElementById('custom_password').setAttribute('required', '');
                document.getElementById('confirm_password').setAttribute('required', '');
            } else {
                fields.classList.add('hidden');
                note.textContent = 'La contraseña será el número de DNI del usuario.';
                document.getElementById('custom_password').removeAttribute('required');
                document.getElementById('confirm_password').removeAttribute('required');
            }
        }
        
        // Check password strength
        function checkPasswordStrength() {
            const password = document.getElementById('custom_password').value;
            const strengthDiv = document.getElementById('password_strength');
            
            let strength = 0;
            let feedback = [];
            
            if (password.length >= 8) strength++;
            else feedback.push('Mínimo 8 caracteres');
            
            if (/[A-Z]/.test(password)) strength++;
            else feedback.push('Una mayúscula');
            
            if (/[a-z]/.test(password)) strength++;
            else feedback.push('Una minúscula');
            
            if (/[0-9]/.test(password)) strength++;
            else feedback.push('Un número');
            
            if (strength === 4) {
                strengthDiv.innerHTML = '<span class="strength-strong">✅ Contraseña fuerte</span>';
            } else if (strength >= 2) {
                strengthDiv.innerHTML = '<span class="strength-medium">⚠️ Contraseña media - Falta: ' + feedback.join(', ') + '</span>';
            } else {
                strengthDiv.innerHTML = '<span class="strength-weak">❌ Contraseña débil - Falta: ' + feedback.join(', ') + '</span>';
            }
        }
        
        // Check password strength in modal
        function checkPasswordStrengthModal() {
            const password = document.getElementById('new_password').value;
            const strengthDiv = document.getElementById('password_strength_modal');
            
            let strength = 0;
            let feedback = [];
            
            if (password.length >= 8) strength++;
            else feedback.push('Mínimo 8 caracteres');
            
            if (/[A-Z]/.test(password)) strength++;
            else feedback.push('Una mayúscula');
            
            if (/[a-z]/.test(password)) strength++;
            else feedback.push('Una minúscula');
            
            if (/[0-9]/.test(password)) strength++;
            else feedback.push('Un número');
            
            if (strength === 4) {
                strengthDiv.innerHTML = '<span class="strength-strong">✅ Contraseña fuerte</span>';
            } else if (strength >= 2) {
                strengthDiv.innerHTML = '<span class="strength-medium">⚠️ Contraseña media - Falta: ' + feedback.join(', ') + '</span>';
            } else {
                strengthDiv.innerHTML = '<span class="strength-weak">❌ Contraseña débil - Falta: ' + feedback.join(', ') + '</span>';
            }
        }
        
        // Toggle dropdown menu
        function toggleDropdown(btn) {
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                if (dropdown !== btn.parentElement) {
                    dropdown.classList.remove('active');
                }
            });
            btn.parentElement.classList.toggle('active');
        }
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.dropdown')) {
                document.querySelectorAll('.dropdown').forEach(dropdown => {
                    dropdown.classList.remove('active');
                });
            }
        });
        
        // DNI validation
        document.getElementById('dni').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 8) {
                value = value.substring(0, 8);
            }
            e.target.value = value;
            
            if (value.length === 8) {
                e.target.style.borderColor = '#00c853';
            } else {
                e.target.style.borderColor = '#e1e8ed';
            }
        });
        
        // Filter table
        function filterTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('usersTable');
            const tr = table.getElementsByTagName('tr');
            
            for (let i = 1; i < tr.length; i++) {
                const td = tr[i].getElementsByTagName('td');
                let txtValue = '';
                for (let j = 0; j < td.length - 1; j++) {
                    txtValue += td[j].textContent || td[j].innerText;
                }
                
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = '';
                } else {
                    tr[i].style.display = 'none';
                }
            }
        }
        
        // Edit user
        function editUser(userId) {
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                dropdown.classList.remove('active');
            });
            
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'ajax_action=get_user&user_id=' + userId
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('edit_user_id').value = data.id;
                document.getElementById('edit_dni').value = data.dni;
                document.getElementById('edit_nombres').value = data.nombres;
                document.getElementById('edit_apellidos').value = data.apellidos;
                document.getElementById('edit_email').value = data.email || '';
                document.getElementById('edit_tipo_usuario').value = data.tipo_usuario;
                
                document.getElementById('editModal').style.display = 'block';
            });
        }
        
        // Change password
        function changePassword(userId) {
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                dropdown.classList.remove('active');
            });
            
            document.getElementById('password_user_id').value = userId;
            document.getElementById('new_password').value = '';
            document.getElementById('confirm_new_password').value = '';
            document.getElementById('password_strength_modal').innerHTML = '';
            
            document.getElementById('passwordModal').style.display = 'block';
        }
        
        // Close modal
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Save user changes
        document.getElementById('editUserForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData();
            formData.append('ajax_action', 'update_user');
            formData.append('user_id', document.getElementById('edit_user_id').value);
            formData.append('dni', document.getElementById('edit_dni').value);
            formData.append('nombres', document.getElementById('edit_nombres').value);
            formData.append('apellidos', document.getElementById('edit_apellidos').value);
            formData.append('email', document.getElementById('edit_email').value);
            formData.append('tipo_usuario', document.getElementById('edit_tipo_usuario').value);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ ' + data.message);
                }
            });
        });
        
        // Save password changes
        document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_new_password').value;
            
            if (newPassword !== confirmPassword) {
                alert('❌ Las contraseñas no coinciden');
                return;
            }
            
            const formData = new FormData();
            formData.append('ajax_action', 'change_password');
            formData.append('user_id', document.getElementById('password_user_id').value);
            formData.append('new_password', newPassword);
            formData.append('confirm_password', confirmPassword);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✅ ' + data.message);
                    closeModal('passwordModal');
                } else {
                    alert('❌ ' + data.message);
                }
            });
        });
        
        // Toggle user status
        function toggleUserStatus(userId) {
            if (confirm('¿Está seguro de cambiar el estado de este usuario?')) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'ajax_action=toggle_status&user_id=' + userId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ Estado actualizado exitosamente');
                        location.reload();
                    } else {
                        alert('❌ ' + (data.message || 'Error al actualizar el estado'));
                    }
                });
            }
        }
        
        // Reset password
        function resetPassword(userId) {
            if (confirm('¿Está seguro de resetear la contraseña de este usuario? Se establecerá como su DNI.')) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'ajax_action=reset_password&user_id=' + userId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ ' + data.message);
                    } else {
                        alert('❌ ' + (data.message || 'Error al resetear la contraseña'));
                    }
                });
            }
        }
        
        // Delete user
        function deleteUser(userId) {
            if (confirm('⚠️ ¿Está seguro de ELIMINAR este usuario? Esta acción no se puede deshacer.')) {
                if (confirm('⚠️ ⚠️ SEGUNDA CONFIRMACIÓN: ¿Realmente desea eliminar este usuario y todos sus datos asociados?')) {
                    fetch('', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'ajax_action=delete_user&user_id=' + userId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('✅ ' + data.message);
                            location.reload();
                        } else {
                            alert('❌ ' + data.message);
                        }
                    });
                }
            }
        }
        
        // Scroll to top
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const editModal = document.getElementById('editModal');
            const passwordModal = document.getElementById('passwordModal');
            
            if (event.target == editModal) {
                editModal.style.display = 'none';
            }
            
            if (event.target == passwordModal) {
                passwordModal.style.display = 'none';
            }
        }
        
        // Animation for cards
        const cards = document.querySelectorAll('.card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            setTimeout(() => {
                card.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
        
        // Form validation
        document.getElementById('createUserForm').addEventListener('submit', function(e) {
            const passwordPersonalizada = document.getElementById('password_personalizada').checked;
            
            if (passwordPersonalizada) {
                const password = document.getElementById('custom_password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                
                if (password !== confirmPassword) {
                    e.preventDefault();
                    alert('❌ Las contraseñas no coinciden');
                    return;
                }
                
                // Validate password strength
                let strength = 0;
                if (password.length >= 8) strength++;
                if (/[A-Z]/.test(password)) strength++;
                if (/[a-z]/.test(password)) strength++;
                if (/[0-9]/.test(password)) strength++;
                
                if (strength < 4) {
                    e.preventDefault();
                    alert('❌ La contraseña no cumple con todos los requisitos de seguridad');
                    return;
                }
            }
        });
    </script>
</body>
</html>