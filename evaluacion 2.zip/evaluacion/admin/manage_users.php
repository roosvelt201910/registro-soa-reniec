<?php
// admin/users.php - Sistema de Gestión de Usuarios Ultra Mejorado con Dropdown Corregido
session_start();

// ==================== CONFIGURACIÓN DE BASE DE DATOS ====================
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'sistema_academico';

// Crear conexión
$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecer charset UTF-8
$conexion->set_charset("utf8mb4");
date_default_timezone_set('America/Lima');

// ==================== VERIFICACIÓN DE PERMISOS ====================
// Verificar si el usuario es super_admin
if (!isset($_SESSION['user_id']) || $_SESSION['tipo_usuario'] != 'super_admin') {
    // Si no hay sesión, establecer valores por defecto para pruebas
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['user_id'] = 1;
        $_SESSION['tipo_usuario'] = 'super_admin';
        $_SESSION['nombres'] = 'Super';
        $_SESSION['apellidos'] = 'Administrador';
    }
}

$message = '';
$messageType = '';

// ==================== PROCESAR ACCIONES AJAX ====================
if (isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    
    switch($_POST['ajax_action']) {
        case 'get_user':
            $user_id = intval($_POST['user_id']);
            $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            echo json_encode($user);
            exit;
            
        case 'update_user':
            $user_id = intval($_POST['user_id']);
            $dni = $_POST['dni'];
            $nombres = $_POST['nombres'];
            $apellidos = $_POST['apellidos'];
            $email = $_POST['email'];
            $tipo_usuario = $_POST['tipo_usuario'];
            
            $stmt = $conexion->prepare("UPDATE usuarios SET dni = ?, nombres = ?, apellidos = ?, email = ?, tipo_usuario = ? WHERE id = ?");
            $stmt->bind_param("sssssi", $dni, $nombres, $apellidos, $email, $tipo_usuario, $user_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Usuario actualizado exitosamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar usuario']);
            }
            exit;
            
        case 'toggle_status':
            $user_id = intval($_POST['user_id']);
            
            // Primero obtener el estado actual
            $stmt = $conexion->prepare("SELECT estado FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            $new_status = ($user['estado'] == 'activo') ? 'inactivo' : 'activo';
            
            $stmt = $conexion->prepare("UPDATE usuarios SET estado = ? WHERE id = ?");
            $stmt->bind_param("si", $new_status, $user_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'new_status' => $new_status]);
            } else {
                echo json_encode(['success' => false]);
            }
            exit;
            
        case 'reset_password':
            $user_id = intval($_POST['user_id']);
            
            // Obtener DNI del usuario
            $stmt = $conexion->prepare("SELECT dni FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            // Resetear contraseña al DNI
            $new_password = password_hash($user['dni'], PASSWORD_DEFAULT);
            
            $stmt = $conexion->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $new_password, $user_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Contraseña reseteada al DNI del usuario']);
            } else {
                echo json_encode(['success' => false]);
            }
            exit;
            
        case 'delete_user':
            $user_id = intval($_POST['user_id']);
            
            // No permitir eliminar el super admin principal
            if ($user_id == 1) {
                echo json_encode(['success' => false, 'message' => 'No se puede eliminar el Super Administrador principal']);
                exit;
            }
            
            // No permitir eliminar el usuario actual
            if ($user_id == $_SESSION['user_id']) {
                echo json_encode(['success' => false, 'message' => 'No puede eliminar su propio usuario']);
                exit;
            }
            
            // Iniciar transacción
            $conexion->begin_transaction();
            
            try {
                // Eliminar registros relacionados
                $conexion->query("DELETE FROM matriculas WHERE estudiante_id = $user_id");
                $conexion->query("DELETE FROM asistencias WHERE estudiante_id = $user_id");
                $conexion->query("DELETE FROM evaluaciones_sesion WHERE estudiante_id = $user_id");
                
                // Eliminar el usuario
                $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                
                $conexion->commit();
                echo json_encode(['success' => true, 'message' => 'Usuario eliminado exitosamente']);
            } catch (Exception $e) {
                $conexion->rollback();
                echo json_encode(['success' => false, 'message' => 'Error al eliminar usuario']);
            }
            exit;
    }
}

// ==================== PROCESAR CREACIÓN DE USUARIO ====================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'create_user') {
    $dni = trim($_POST['dni']);
    $nombres = trim($_POST['nombres']);
    $apellidos = trim($_POST['apellidos']);
    $email = trim($_POST['email']);
    $tipo_usuario = $_POST['tipo_usuario'];
    
    // Validaciones
    if (strlen($dni) != 8 || !is_numeric($dni)) {
        $message = '❌ El DNI debe tener exactamente 8 dígitos numéricos.';
        $messageType = 'error';
    } else {
        // Verificar si el DNI ya existe
        $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE dni = ?");
        $stmt->bind_param("s", $dni);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $message = '❌ Ya existe un usuario con ese DNI.';
            $messageType = 'error';
        } else {
            // Crear usuario con contraseña = DNI
            $password_hash = password_hash($dni, PASSWORD_DEFAULT);
            
            $stmt = $conexion->prepare("INSERT INTO usuarios (dni, nombres, apellidos, email, password, tipo_usuario, estado, fecha_creacion) VALUES (?, ?, ?, ?, ?, ?, 'activo', NOW())");
            $stmt->bind_param("ssssss", $dni, $nombres, $apellidos, $email, $password_hash, $tipo_usuario);
            
            if ($stmt->execute()) {
                $message = '✅ Usuario creado exitosamente. Contraseña: ' . $dni;
                $messageType = 'success';
            } else {
                $message = '❌ Error al crear el usuario.';
                $messageType = 'error';
            }
        }
    }
}

// ==================== OBTENER LISTA DE USUARIOS ====================
$query = "SELECT u.*, 
          (SELECT COUNT(*) FROM matriculas WHERE estudiante_id = u.id AND estado = 'activo') as cursos_matriculados,
          (SELECT COUNT(*) FROM unidades_didacticas WHERE docente_id = u.id AND estado = 'activo') as cursos_asignados
          FROM usuarios u 
          ORDER BY u.fecha_creacion DESC";
$result = $conexion->query($query);
$usuarios = [];
while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
}

// Estadísticas
$total_users = count(array_filter($usuarios, function($u) { return $u['estado'] == 'activo'; }));
$docentes = count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'docente' && $u['estado'] == 'activo'; }));
$estudiantes = count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'estudiante' && $u['estado'] == 'activo'; }));
$admins = count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'super_admin' && $u['estado'] == 'activo'; }));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚀 Gestión de Usuarios - Sistema Académico Ultra</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }
        
        /* Header Ultra */
        .header {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
            padding: 1.5rem 2rem;
        }
        
        .header h1 {
            font-size: 2em;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 800;
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        /* Stats Grid Ultra */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
            animation: fadeInUp 0.6s ease;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2, #667eea);
            background-size: 200% 100%;
            animation: shimmer 3s infinite;
        }
        
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        
        .stat-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
        }
        
        .stat-icon {
            font-size: 3em;
            margin-bottom: 15px;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: 800;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 1em;
            color: #6c757d;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Card Ultra */
        .card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        
        .card h2 {
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 3px solid #f0f0f0;
            position: relative;
        }
        
        .card h2::after {
            content: '';
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            animation: expand 1s ease;
        }
        
        @keyframes expand {
            from { width: 0; }
            to { width: 100px; }
        }
        
        /* Form Ultra */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 0.95em;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e1e8ed;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: #f8f9fa;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }
        
        /* Buttons Ultra */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 15px;
            font-weight: 600;
            margin-right: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn:hover::before {
            width: 300%;
            height: 300%;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #00c853 0%, #00e676 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(0, 200, 83, 0.3);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ff5252 0%, #ff1744 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(255, 23, 68, 0.3);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #ffb300 0%, #ffc107 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.3);
        }
        
        .btn-info {
            background: linear-gradient(135deg, #00bcd4 0%, #00acc1 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(0, 188, 212, 0.3);
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }
        
        /* Table Ultra */
        .table-container {
            overflow-x: auto;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            position: relative;
        }
        
        .search-bar {
            margin-bottom: 20px;
            position: relative;
        }
        
        .search-bar input {
            width: 100%;
            padding: 14px 20px 14px 50px;
            border: 2px solid #e1e8ed;
            border-radius: 50px;
            font-size: 15px;
            transition: all 0.3s;
            background: white;
        }
        
        .search-bar input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .search-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .users-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .users-table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .users-table th {
            padding: 18px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .users-table th:first-child {
            border-top-left-radius: 15px;
        }
        
        .users-table th:last-child {
            border-top-right-radius: 15px;
        }
        
        .users-table td {
            padding: 16px 18px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }
        
        .users-table tbody tr {
            background: white;
            transition: all 0.3s;
        }
        
        .users-table tbody tr:hover {
            background: #f8f9fa;
            transform: scale(1.01);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        /* Badges Ultra */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            display: inline-block;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }
        
        .badge-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }
        
        .badge-primary {
            background: linear-gradient(135deg, #cfe2ff 0%, #b6d4fe 100%);
            color: #084298;
        }
        
        .badge-warning {
            background: linear-gradient(135deg, #fff3cd 0%, #ffe69c 100%);
            color: #664d03;
        }
        
        .badge-info {
            background: linear-gradient(135deg, #cff4fc 0%, #b6effb 100%);
            color: #055160;
        }
        
        /* Alert Messages */
        .alert {
            padding: 20px 25px;
            border-radius: 15px;
            margin-bottom: 25px;
            position: relative;
            animation: slideInAlert 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        @keyframes slideInAlert {
            from {
                opacity: 0;
                transform: translateX(-50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateX(0) scale(1);
            }
        }
        
        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            border-left: 5px solid #28a745;
        }
        
        .alert-error {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
            border-left: 5px solid #dc3545;
        }
        
        .alert-icon {
            font-size: 2em;
        }
        
        /* Modal Ultra */
        .modal {
            display: none;
            position: fixed;
            z-index: 10000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            animation: fadeInModal 0.3s ease;
        }
        
        @keyframes fadeInModal {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .modal-content {
            background: white;
            margin: 50px auto;
            padding: 0;
            border-radius: 20px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: slideUpModal 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            overflow: hidden;
        }
        
        @keyframes slideUpModal {
            from {
                transform: translateY(100px) scale(0.9);
                opacity: 0;
            }
            to {
                transform: translateY(0) scale(1);
                opacity: 1;
            }
        }
        
        .modal-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            font-size: 1.5em;
            font-weight: 700;
        }
        
        .close {
            color: white;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s;
            background: none;
            border: none;
        }
        
        .close:hover {
            transform: rotate(90deg);
        }
        
        .modal-body {
            padding: 30px;
        }
        
        /* Actions Dropdown - CORREGIDO CON Z-INDEX ALTO */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        
        .dropdown-toggle {
            cursor: pointer;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 220px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.3);
            z-index: 999999; /* Z-INDEX MUY ALTO PARA QUE SIEMPRE ESTÉ ENCIMA */
            border-radius: 15px;
            overflow: hidden;
            margin-top: 5px;
            border: 2px solid rgba(102, 126, 234, 0.1);
            animation: dropdownSlide 0.3s ease;
        }
        
        @keyframes dropdownSlide {
            from {
                opacity: 0;
                transform: translateY(-10px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        .dropdown.active .dropdown-content {
            display: block;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 14px 20px;
            text-decoration: none;
            display: flex;
            align-items: right;
            gap: 10px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }
        
        .dropdown-content a::before {
            content: '';
            position: absolute;
            left: -100%;
            top: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #093774ff 0%, #030b9bff 100%);
            transition: left 0.3s;
            z-index: -10;
        }
        
        .dropdown-content a:hover::before {
            left: 0;
        }
        
        .dropdown-content a:hover {
            color: white;
            padding-left: 30px;
        }
        
        .dropdown-content a:not(:last-child) {
            border-bottom: 1px solid #f0f0f0;
        }
        
        /* Loading Spinner */
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            vertical-align: middle;
            margin-left: 10px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 0 1rem;
            }
            
            .header-content {
                flex-direction: column;
                gap: 15px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .users-table {
                font-size: 12px;
            }
            
            .btn {
                font-size: 12px;
                padding: 8px 16px;
            }
            
            .dropdown-content {
                right: 100px;
                left: -110;
            }
        }
        
        /* Tooltip */
        .tooltip {
            position: relative;
            display: inline-block;
        }
        
        .tooltip .tooltiptext {
            visibility: hidden;
            width: 200px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            border-radius: 10px;
            padding: 10px;
            position: absolute;
            z-index: 100000;
            bottom: 125%;
            left: 50%;
            margin-left: -100px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 13px;
        }
        
        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }
        
        /* Floating Action Button */
        .fab {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 99;
        }
        
        .fab:hover {
            transform: scale(1.1) rotate(90deg);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.5);
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>🚀 Gestión de Usuarios</h1>
            <div>
                <span style="margin-right: 20px; font-weight: 600;">
                    👤 <?php echo $_SESSION['apellidos'] . ', ' . $_SESSION['nombres']; ?>
                </span>
                <a href="../dashboard.php" class="btn btn-primary">
                    ← Volver al Dashboard
                </a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <span class="alert-icon"><?php echo $messageType == 'success' ? '✅' : '❌'; ?></span>
                <span><?php echo $message; ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div class="stat-label">Usuarios Activos</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍🏫</div>
                <div class="stat-number"><?php echo $docentes; ?></div>
                <div class="stat-label">Docentes</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍🎓</div>
                <div class="stat-number"><?php echo $estudiantes; ?></div>
                <div class="stat-label">Estudiantes</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👨‍💼</div>
                <div class="stat-number"><?php echo $admins; ?></div>
                <div class="stat-label">Administradores</div>
            </div>
        </div>
        
        <!-- Formulario para crear usuario -->
        <div class="card">
            <h2>✨ Crear Nuevo Usuario</h2>
            <form method="POST" id="createUserForm">
                <input type="hidden" name="action" value="create_user">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="dni">DNI <span style="color: #ff1744;">*</span></label>
                        <input type="text" 
                               id="dni" 
                               name="dni" 
                               maxlength="8" 
                               pattern="[0-9]{8}" 
                               placeholder="Ej: 12345678"
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo_usuario">Tipo de Usuario <span style="color: #ff1744;">*</span></label>
                        <select name="tipo_usuario" id="tipo_usuario" required>
                            <option value="">Seleccione...</option>
                            <option value="super_admin">👨‍💼 Super Administrador</option>
                            <option value="docente">👨‍🏫 Docente</option>
                            <option value="estudiante">👨‍🎓 Estudiante</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombres">Nombres <span style="color: #ff1744;">*</span></label>
                        <input type="text" 
                               id="nombres" 
                               name="nombres" 
                               placeholder="Ej: Juan Carlos"
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="apellidos">Apellidos <span style="color: #ff1744;">*</span></label>
                        <input type="text" 
                               id="apellidos" 
                               name="apellidos" 
                               placeholder="Ej: García López"
                               required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               placeholder="usuario@ejemplo.com">
                    </div>
                </div>
                
                <div style="background: linear-gradient(135deg, #fff3cd 0%, #ffe69c 100%); padding: 20px; border-radius: 15px; border-left: 5px solid #ffc107; margin-bottom: 25px;">
                    <p style="margin: 0; color: #664d03; font-weight: 600;">
                        <strong>📌 Nota:</strong> La contraseña será el número de DNI del usuario. Deberá cambiarla en su primer inicio de sesión.
                    </p>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <span>CREAR USUARIO</span>
                </button>
            </form>
        </div>
        
        <!-- Lista de usuarios -->
        <div class="card">
            <h2>📋 Lista de Usuarios Registrados</h2>
            
            <div class="search-bar">
                <span class="search-icon">🔍</span>
                <input type="text" id="searchInput" placeholder="Buscar por nombre, DNI, email..." onkeyup="filterTable()">
            </div>
            
            <?php if (empty($usuarios)): ?>
                <p style="text-align: center; padding: 40px; color: #6c757d;">No hay usuarios registrados en el sistema.</p>
            <?php else: ?>
                <div class="table-container">
                    <table class="users-table" id="usersTable">
                        <thead>
                            <tr>
                                <th>DNI</th>
                                <th>Nombre Completo</th>
                                <th>Email</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                                <th>Cursos</th>
                                <th>Registro</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($usuarios as $usuario): ?>
                                <tr data-user-id="<?php echo $usuario['id']; ?>">
                                    <td><strong><?php echo htmlspecialchars($usuario['dni']); ?></strong></td>
                                    <td>
                                        <div style="font-weight: 600;"><?php echo htmlspecialchars($usuario['apellidos'] . ', ' . $usuario['nombres']); ?></div>
                                    </td>
                                    <td><?php echo htmlspecialchars($usuario['email'] ?: 'No especificado'); ?></td>
                                    <td>
                                        <?php
                                        $tipo_badge = '';
                                        $tipo_icon = '';
                                        switch($usuario['tipo_usuario']) {
                                            case 'super_admin':
                                                $tipo_badge = 'badge-primary';
                                                $tipo_icon = '👨‍💼';
                                                break;
                                            case 'docente':
                                                $tipo_badge = 'badge-info';
                                                $tipo_icon = '👨‍🏫';
                                                break;
                                            case 'estudiante':
                                                $tipo_badge = 'badge-success';
                                                $tipo_icon = '👨‍🎓';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?php echo $tipo_badge; ?>">
                                            <?php echo $tipo_icon . ' ' . ucfirst(str_replace('_', ' ', $usuario['tipo_usuario'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $usuario['estado'] == 'activo' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo $usuario['estado'] == 'activo' ? '✅ Activo' : '❌ Inactivo'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($usuario['tipo_usuario'] == 'estudiante'): ?>
                                            <span class="badge badge-warning"><?php echo $usuario['cursos_matriculados']; ?> cursos</span>
                                        <?php elseif ($usuario['tipo_usuario'] == 'docente'): ?>
                                            <span class="badge badge-warning"><?php echo $usuario['cursos_asignados']; ?> cursos</span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($usuario['fecha_creacion'])); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-primary btn-sm dropdown-toggle" onclick="toggleDropdown(this)">
                                                ⚙️ Acciones ▼
                                            </button>
                                            <div class="dropdown-content">
                                                <a href="#" onclick="editUser(<?php echo $usuario['id']; ?>)">
                                                    ✏️ Editar Usuario
                                                </a>
                                                <a href="#" onclick="resetPassword(<?php echo $usuario['id']; ?>)">
                                                    🔐 Resetear Contraseña
                                                </a>
                                                <?php if ($usuario['id'] != $_SESSION['user_id'] && $usuario['id'] != 1): ?>
                                                    <a href="#" onclick="toggleUserStatus(<?php echo $usuario['id']; ?>)">
                                                        <?php echo $usuario['estado'] == 'activo' ? '⏸️ Desactivar Usuario' : '▶️ Activar Usuario'; ?>
                                                    </a>
                                                    <a href="#" onclick="deleteUser(<?php echo $usuario['id']; ?>)" style="color: #dc3545;">
                                                        🗑️ Eliminar Usuario
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal para editar usuario -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>✏️ Editar Usuario</h2>
                <button class="close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <input type="hidden" id="edit_user_id">
                    
                    <div class="form-group">
                        <label>DNI</label>
                        <input type="text" id="edit_dni" maxlength="8" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Nombres</label>
                        <input type="text" id="edit_nombres" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Apellidos</label>
                        <input type="text" id="edit_apellidos" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="edit_email">
                    </div>
                    
                    <div class="form-group">
                        <label>Tipo de Usuario</label>
                        <select id="edit_tipo_usuario" required>
                            <option value="super_admin">👨‍💼 Super Administrador</option>
                            <option value="docente">👨‍🏫 Docente</option>
                            <option value="estudiante">👨‍🎓 Estudiante</option>
                        </select>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button type="submit" class="btn btn-success">💾 Guardar Cambios</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal()">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Floating Action Button -->
    <div class="fab" onclick="scrollToTop()">
        ↑
    </div>
    
    <script>
        // Toggle dropdown menu
        function toggleDropdown(btn) {
            // Cerrar todos los otros dropdowns
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                if (dropdown !== btn.parentElement) {
                    dropdown.classList.remove('active');
                }
            });
            
            // Toggle el dropdown actual
            btn.parentElement.classList.toggle('active');
        }
        
        // Cerrar dropdowns al hacer clic fuera
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.dropdown')) {
                document.querySelectorAll('.dropdown').forEach(dropdown => {
                    dropdown.classList.remove('active');
                });
            }
        });
        
        // Validación del DNI en tiempo real
        document.getElementById('dni').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 8) {
                value = value.substring(0, 8);
            }
            e.target.value = value;
            
            // Visual feedback
            if (value.length === 8) {
                e.target.style.borderColor = '#00c853';
            } else {
                e.target.style.borderColor = '#e1e8ed';
            }
        });
        
        // Función para filtrar la tabla
        function filterTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('usersTable');
            const tr = table.getElementsByTagName('tr');
            
            for (let i = 1; i < tr.length; i++) {
                const td = tr[i].getElementsByTagName('td');
                let txtValue = '';
                for (let j = 0; j < td.length - 1; j++) {
                    txtValue += td[j].textContent || td[j].innerText;
                }
                
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = '';
                } else {
                    tr[i].style.display = 'none';
                }
            }
        }
        
        // Función para editar usuario
        function editUser(userId) {
            // Cerrar dropdown
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                dropdown.classList.remove('active');
            });
            
            // Hacer petición AJAX para obtener datos del usuario
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'ajax_action=get_user&user_id=' + userId
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('edit_user_id').value = data.id;
                document.getElementById('edit_dni').value = data.dni;
                document.getElementById('edit_nombres').value = data.nombres;
                document.getElementById('edit_apellidos').value = data.apellidos;
                document.getElementById('edit_email').value = data.email || '';
                document.getElementById('edit_tipo_usuario').value = data.tipo_usuario;
                
                document.getElementById('editModal').style.display = 'block';
            });
        }
        
        // Función para cerrar modal
        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        // Guardar cambios del usuario
        document.getElementById('editUserForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData();
            formData.append('ajax_action', 'update_user');
            formData.append('user_id', document.getElementById('edit_user_id').value);
            formData.append('dni', document.getElementById('edit_dni').value);
            formData.append('nombres', document.getElementById('edit_nombres').value);
            formData.append('apellidos', document.getElementById('edit_apellidos').value);
            formData.append('email', document.getElementById('edit_email').value);
            formData.append('tipo_usuario', document.getElementById('edit_tipo_usuario').value);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ ' + data.message);
                }
            });
        });
        
        // Función para cambiar estado del usuario
        function toggleUserStatus(userId) {
            if (confirm('¿Está seguro de cambiar el estado de este usuario?')) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'ajax_action=toggle_status&user_id=' + userId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ Estado actualizado exitosamente');
                        location.reload();
                    } else {
                        alert('❌ Error al actualizar el estado');
                    }
                });
            }
        }
        
        // Función para resetear contraseña
        function resetPassword(userId) {
            if (confirm('¿Está seguro de resetear la contraseña de este usuario? Se establecerá como su DNI.')) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'ajax_action=reset_password&user_id=' + userId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ ' + data.message);
                    } else {
                        alert('❌ Error al resetear la contraseña');
                    }
                });
            }
        }
        
        // Función para eliminar usuario
        function deleteUser(userId) {
            if (confirm('⚠️ ¿Está seguro de ELIMINAR este usuario? Esta acción no se puede deshacer.')) {
                if (confirm('⚠️ ⚠️ SEGUNDA CONFIRMACIÓN: ¿Realmente desea eliminar este usuario y todos sus datos asociados?')) {
                    fetch('', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'ajax_action=delete_user&user_id=' + userId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('✅ ' + data.message);
                            location.reload();
                        } else {
                            alert('❌ ' + data.message);
                        }
                    });
                }
            }
        }
        
        // Scroll to top
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
        
        // Cerrar modal al hacer clic fuera
        window.onclick = function(event) {
            const modal = document.getElementById('editModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        // Animación de entrada para las cards
        const cards = document.querySelectorAll('.card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            setTimeout(() => {
                card.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    </script>
</body>
</html>