<?php
// teacher/attendance.php - Sistema de Asistencia (Sin Login)
session_start();

// ==================== CONFIGURACIÓN DE BASE DE DATOS ====================
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'sistema_academico';

// Crear conexión
$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecer charset UTF-8
$conexion->set_charset("utf8mb4");
date_default_timezone_set('America/Lima');

// ==================== CONFIGURACIÓN DE USUARIO ====================
// Si no hay sesión, establecer valores por defecto para pruebas
if (!isset($_SESSION['usuario_id'])) {
    // Buscar el primer docente en la BD para pruebas
    $result = $conexion->query("SELECT id, dni, nombres, apellidos FROM usuarios WHERE tipo_usuario = 'docente' AND estado = 'activo' LIMIT 1");
    if ($result && $result->num_rows > 0) {
        $docente = $result->fetch_assoc();
        $_SESSION['usuario_id'] = $docente['id'];
        $_SESSION['nombres'] = $docente['nombres'];
        $_SESSION['apellidos'] = $docente['apellidos'];
        $_SESSION['tipo_usuario'] = 'docente';
    } else {
        die("No se encontró ningún docente activo en la base de datos");
    }
}

$docente_id = $_SESSION['usuario_id'];
$mensaje = '';
$tipo_mensaje = '';

// ==================== PROCESAR ASISTENCIA ====================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['guardar_asistencia'])) {
    $sesion_id = $_POST['sesion_id'];
    $fecha = $_POST['fecha_sesion'];
    
    try {
        $conexion->begin_transaction();
        
        // Actualizar la sesión como realizada
        $stmt = $conexion->prepare("UPDATE sesiones SET estado = 'realizada', fecha = ? WHERE id = ?");
        $stmt->bind_param("si", $fecha, $sesion_id);
        $stmt->execute();
        
        // Guardar asistencia de cada estudiante
        if (isset($_POST['asistencia'])) {
            foreach ($_POST['asistencia'] as $estudiante_id => $estado) {
                $observaciones = isset($_POST['observaciones'][$estudiante_id]) ? $_POST['observaciones'][$estudiante_id] : '';
                
                // Verificar si ya existe un registro
                $check = $conexion->prepare("SELECT id FROM asistencias WHERE sesion_id = ? AND estudiante_id = ?");
                $check->bind_param("ii", $sesion_id, $estudiante_id);
                $check->execute();
                $result = $check->get_result();
                
                if ($result->num_rows > 0) {
                    // Actualizar registro existente
                    $stmt = $conexion->prepare("UPDATE asistencias SET estado = ?, observaciones = ?, fecha_registro = NOW() WHERE sesion_id = ? AND estudiante_id = ?");
                    $stmt->bind_param("ssii", $estado, $observaciones, $sesion_id, $estudiante_id);
                } else {
                    // Insertar nuevo registro
                    $stmt = $conexion->prepare("INSERT INTO asistencias (sesion_id, estudiante_id, estado, observaciones) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("iiss", $sesion_id, $estudiante_id, $estado, $observaciones);
                }
                $stmt->execute();
            }
        }
        
        $conexion->commit();
        $mensaje = "✅ Asistencia guardada correctamente";
        $tipo_mensaje = "success";
        
    } catch (Exception $e) {
        $conexion->rollback();
        $mensaje = "❌ Error al guardar la asistencia: " . $e->getMessage();
        $tipo_mensaje = "error";
    }
}

// ==================== CREAR NUEVA SESIÓN ====================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['crear_sesion'])) {
    $unidad_didactica_id = $_POST['unidad_didactica_id'];
    $numero_sesion = $_POST['numero_sesion'];
    $titulo = $_POST['titulo'];
    $fecha = $_POST['fecha'];
    $descripcion = $_POST['descripcion'] ?? '';
    
    // Verificar que el número de sesión no exista
    $check = $conexion->prepare("SELECT id FROM sesiones WHERE unidad_didactica_id = ? AND numero_sesion = ?");
    $check->bind_param("ii", $unidad_didactica_id, $numero_sesion);
    $check->execute();
    $result = $check->get_result();
    
    if ($result->num_rows > 0) {
        $mensaje = "❌ Ya existe una sesión con ese número";
        $tipo_mensaje = "error";
    } else {
        // Insertar nueva sesión
        $stmt = $conexion->prepare("INSERT INTO sesiones (unidad_didactica_id, numero_sesion, titulo, fecha, descripcion, estado) VALUES (?, ?, ?, ?, ?, 'programada')");
        $stmt->bind_param("iisss", $unidad_didactica_id, $numero_sesion, $titulo, $fecha, $descripcion);
        
        if ($stmt->execute()) {
            $nueva_sesion_id = $conexion->insert_id;
            $mensaje = "✅ Sesión creada exitosamente";
            $tipo_mensaje = "success";
            header("Location: attendance.php?unidad_id=" . $unidad_didactica_id . "&sesion_id=" . $nueva_sesion_id);
            exit();
        }
    }
}

// ==================== OBTENER DATOS ====================
// Obtener unidades didácticas del docente
$query_unidades = "SELECT ud.*, pe.nombre as programa_nombre, 
                   (SELECT COUNT(DISTINCT m.estudiante_id) FROM matriculas m WHERE m.unidad_didactica_id = ud.id AND m.estado = 'activo') as total_estudiantes
                   FROM unidades_didacticas ud
                   LEFT JOIN programas_estudio pe ON ud.programa_id = pe.id
                   WHERE ud.docente_id = ? AND ud.estado = 'activo'
                   ORDER BY ud.periodo_lectivo DESC, ud.nombre";
$stmt = $conexion->prepare($query_unidades);
$stmt->bind_param("i", $docente_id);
$stmt->execute();
$unidades = $stmt->get_result();

$unidad_seleccionada = isset($_GET['unidad_id']) ? intval($_GET['unidad_id']) : null;
$sesion_seleccionada = isset($_GET['sesion_id']) ? $_GET['sesion_id'] : null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Asistencia - <?php echo $_SESSION['apellidos'] . ', ' . $_SESSION['nombres']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, #012c7bff 0%, #0d4270ff 100%);
            color: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 600;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        /* Container */
        .container {
            max-width: 1400px;
            margin: 20px auto;
            padding: 0 20px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card-header {
            background: linear-gradient(135deg, #07295fff 0%, #09407eff 100%);
            color: white;
            padding: 15px 20px;
            font-weight: 600;
            font-size: 18px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            animation: slideIn 0.3s ease;
        }
        
        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        /* Forms */
        select, input[type="date"], input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.3s;
        }
        
        select:focus, input:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        textarea {
            resize: vertical;
            min-height: 60px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #05265eff 0%, #012750ff 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background: #e0a800;
        }
        
        /* Table */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table thead {
            background: linear-gradient(135deg, #630808ff 0%, #350000ff 100%);
            color: white;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .table tbody tr:last-child td {
            border-bottom: none;
        }
        
        /* Attendance Options */
        .attendance-options {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .attendance-option {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .attendance-option input[type="radio"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .attendance-option label {
            cursor: pointer;
            margin: 0;
            font-weight: normal;
        }
        
        .attendance-option.presente label { color: #28a745; }
        .attendance-option.falta label { color: #dc3545; }
        .attendance-option.tarde label { color: #ffc107; }
        .attendance-option.permiso label { color: #17a2b8; }
        
        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            text-align: center;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #6c757d;
            font-size: 14px;
        }
        
        /* Session Info */
        .session-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .session-info h3 {
            color: #495057;
            margin-bottom: 15px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .info-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        
        .info-label {
            font-size: 12px;
            color: #6c757d;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .info-value {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        /* Actions */
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .attendance-options {
                flex-direction: column;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                text-align: center;
            }
            
            .table {
                font-size: 14px;
            }
            
            .table th,
            .table td {
                padding: 8px 5px;
            }
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        /* Observaciones Input */
        .obs-input {
            width: 100%;
            padding: 6px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

             .confetti-button {
            position: relative;
            padding: 15px 30px;
            font-size: 18px;
            color: white;
            background: linear-gradient(45deg, #ffffffff, #ffffffff);
            border: none;
            border-radius: 50px;
            cursor: pointer;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        
        .confetti-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            background: linear-gradient(45deg, #ff8c42, #ff3366);
        }
        
        .confetti-button:active {
            transform: translateY(1px);
        }
        
        .confetti-button::after {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, 0.5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }
        
        .confetti-button:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }
        
        @keyframes ripple {
            0% {
                transform: scale(0, 0);
                opacity: 0.5;
            }
            100% {
                transform: scale(20, 20);
                opacity: 0;
            }
        }

    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <h1><i class="fas fa-chart-line"></i> Gestión de Evaluaciones</h1>
            <div class="user-info">
                <span><i class="fas fa-user"></i> <?php echo htmlspecialchars(($_SESSION['nombres'] ?? 'Usuario') . ' ' . ($_SESSION['apellidos'] ?? 'Temporal')); ?></span>
               
            
            <button class="confetti-button" id="confettiBtn"> <a href="../dashboard.php">Dashboard </a></button>

    <script>
        const button = document.getElementById('confettiBtn');
        
        button.addEventListener('click', function(e) {
            // Disparar confeti
            confetti({
                particleCount: 150,
                spread: 70,
                origin: { y: 0.6 }
            });
            
            // Pequeño retraso antes de redirigir para que se vea el confeti
            setTimeout(() => {
                window.location.href = "../dashboard.php";
            }, 1000);
        });
    </script>




            </div>
        </div>
    </div>
    
    <!-- Container -->
    <div class="container">
        <?php if ($mensaje): ?>
            <div class="alert <?php echo $tipo_mensaje; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>
        
        <!-- Selección de Unidad Didáctica -->
        <div class="card">
            <div class="card-header">
                📚 Seleccionar Unidad Didáctica
            </div>
            <div class="card-body">
                <select onchange="window.location.href='attendance.php?unidad_id=' + this.value">
                    <option value="">-- Seleccione una unidad didáctica --</option>
                    <?php 
                    $unidades->data_seek(0);
                    while ($unidad = $unidades->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $unidad['id']; ?>" <?php echo ($unidad_seleccionada == $unidad['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($unidad['nombre']); ?> 
                            | <?php echo $unidad['periodo_academico']; ?> 
                            | <?php echo $unidad['periodo_lectivo']; ?>
                            (<?php echo $unidad['total_estudiantes']; ?> estudiantes)
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
        
        <?php if ($unidad_seleccionada): ?>
            <?php
            // Obtener información de la unidad
            $query_info = "SELECT ud.*, 
                          (SELECT COUNT(*) FROM sesiones WHERE unidad_didactica_id = ud.id) as total_sesiones,
                          (SELECT COUNT(*) FROM sesiones WHERE unidad_didactica_id = ud.id AND estado = 'realizada') as sesiones_realizadas,
                          (SELECT COUNT(DISTINCT m.estudiante_id) FROM matriculas m WHERE m.unidad_didactica_id = ud.id AND m.estado = 'activo') as total_estudiantes
                          FROM unidades_didacticas ud
                          WHERE ud.id = ?";
            $stmt = $conexion->prepare($query_info);
            $stmt->bind_param("i", $unidad_seleccionada);
            $stmt->execute();
            $info_unidad = $stmt->get_result()->fetch_assoc();
            
            // Obtener sesiones
            $query_sesiones = "SELECT s.*, 
                              (SELECT COUNT(*) FROM asistencias WHERE sesion_id = s.id) as asistencias_registradas
                              FROM sesiones s
                              WHERE s.unidad_didactica_id = ? 
                              ORDER BY s.numero_sesion";
            $stmt = $conexion->prepare($query_sesiones);
            $stmt->bind_param("i", $unidad_seleccionada);
            $stmt->execute();
            $sesiones = $stmt->get_result();
            ?>
            
            <!-- Estadísticas -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $info_unidad['total_sesiones']; ?></div>
                    <div class="stat-label">Total Sesiones</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $info_unidad['sesiones_realizadas']; ?></div>
                    <div class="stat-label">Sesiones Realizadas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">
                        <?php 
                        $progreso = $info_unidad['total_sesiones'] > 0 
                            ? round(($info_unidad['sesiones_realizadas'] / $info_unidad['total_sesiones']) * 100) 
                            : 0;
                        echo $progreso . '%';
                        ?>
                    </div>
                    <div class="stat-label">Progreso</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $info_unidad['total_estudiantes']; ?></div>
                    <div class="stat-label">Estudiantes</div>
                </div>
            </div>
            
            <!-- Selección de Sesión -->
            <div class="card">
                <div class="card-header">
                    📅 Seleccionar Sesión de Clase
                </div>
                <div class="card-body">
                    <select onchange="window.location.href='attendance.php?unidad_id=<?php echo $unidad_seleccionada; ?>&sesion_id=' + this.value">
                        <option value="">-- Seleccione una sesión --</option>
                        <option value="nueva">➕ Crear nueva sesión</option>
                        <?php while ($sesion = $sesiones->fetch_assoc()): ?>
                            <option value="<?php echo $sesion['id']; ?>" <?php echo ($sesion_seleccionada == $sesion['id']) ? 'selected' : ''; ?>>
                                Sesión <?php echo $sesion['numero_sesion']; ?>: <?php echo htmlspecialchars($sesion['titulo']); ?> 
                                | <?php echo date('d/m/Y', strtotime($sesion['fecha'])); ?>
                                | <?php echo ucfirst($sesion['estado']); ?>
                                <?php if ($sesion['asistencias_registradas'] > 0): ?>
                                    ✓
                                <?php endif; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            
            <?php if ($sesion_seleccionada == 'nueva'): ?>
                <!-- Crear Nueva Sesión -->
                <div class="card">
                    <div class="card-header">
                        ➕ Crear Nueva Sesión
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="crear_sesion" value="1">
                            <input type="hidden" name="unidad_didactica_id" value="<?php echo $unidad_seleccionada; ?>">
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Número de Sesión *</label>
                                    <input type="number" name="numero_sesion" required min="1">
                                </div>
                                <div class="form-group">
                                    <label>Fecha *</label>
                                    <input type="date" name="fecha" required value="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Título de la Sesión *</label>
                                <input type="text" name="titulo" required placeholder="Ej: Introducción a la farmacología">
                            </div>
                            
                            <div class="form-group">
                                <label>Descripción (Opcional)</label>
                                <textarea name="descripcion" placeholder="Descripción de la sesión..."></textarea>
                            </div>
                            
                            <div class="actions">
                                <button type="submit" class="btn btn-primary">💾 Crear Sesión</button>
                                <a href="attendance.php?unidad_id=<?php echo $unidad_seleccionada; ?>" class="btn btn-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
                
            <?php elseif ($sesion_seleccionada && is_numeric($sesion_seleccionada)): ?>
                <?php
                // Obtener información de la sesión
                $query_info_sesion = "SELECT * FROM sesiones WHERE id = ?";
                $stmt = $conexion->prepare($query_info_sesion);
                $stmt->bind_param("i", $sesion_seleccionada);
                $stmt->execute();
                $info_sesion = $stmt->get_result()->fetch_assoc();
                
                // Obtener estudiantes con su asistencia
                $query_estudiantes = "SELECT u.id, u.dni, u.nombres, u.apellidos,
                                     a.estado as asistencia_estado, a.observaciones
                                     FROM matriculas m
                                     JOIN usuarios u ON m.estudiante_id = u.id
                                     LEFT JOIN asistencias a ON a.estudiante_id = u.id AND a.sesion_id = ?
                                     WHERE m.unidad_didactica_id = ? AND m.estado = 'activo'
                                     ORDER BY u.apellidos, u.nombres";
                $stmt = $conexion->prepare($query_estudiantes);
                $stmt->bind_param("ii", $sesion_seleccionada, $unidad_seleccionada);
                $stmt->execute();
                $estudiantes = $stmt->get_result();
                ?>
                
                <!-- Información de la Sesión -->
                <div class="session-info">
                    <h3>📝 Información de la Sesión</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Sesión N°</div>
                            <div class="info-value"><?php echo $info_sesion['numero_sesion']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Título</div>
                            <div class="info-value"><?php echo htmlspecialchars($info_sesion['titulo']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Fecha</div>
                            <div class="info-value"><?php echo date('d/m/Y', strtotime($info_sesion['fecha'])); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Estado</div>
                            <div class="info-value">
                                <span class="badge badge-<?php echo $info_sesion['estado'] == 'realizada' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($info_sesion['estado']); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php if ($info_sesion['descripcion']): ?>
                        <div style="margin-top: 15px;">
                            <strong>Descripción:</strong> <?php echo htmlspecialchars($info_sesion['descripcion']); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Formulario de Asistencia -->
                <div class="card">
                    <div class="card-header">
                        👥 Registro de Asistencia
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="sesion_id" value="<?php echo $sesion_seleccionada; ?>">
                            <input type="hidden" name="guardar_asistencia" value="1">
                            
                            <div class="form-group">
                                <label>Fecha de la Sesión:</label>
                                <input type="date" name="fecha_sesion" value="<?php echo $info_sesion['fecha']; ?>" required style="max-width: 200px;">
                            </div>
                            
                            <?php if ($estudiantes->num_rows > 0): ?>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="12%">DNI</th>
                                            <th width="28%">Apellidos y Nombres</th>
                                            <th width="35%">Asistencia</th>
                                            <th width="20%">Observaciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $contador = 1;
                                        while ($estudiante = $estudiantes->fetch_assoc()): 
                                        ?>
                                            <tr>
                                                <td><?php echo $contador++; ?></td>
                                                <td><?php echo htmlspecialchars($estudiante['dni']); ?></td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($estudiante['apellidos']); ?></strong>,
                                                    <?php echo htmlspecialchars($estudiante['nombres']); ?>
                                                </td>
                                                <td>
                                                    <div class="attendance-options">
                                                        <div class="attendance-option presente">
                                                            <input type="radio" 
                                                                   id="presente_<?php echo $estudiante['id']; ?>" 
                                                                   name="asistencia[<?php echo $estudiante['id']; ?>]" 
                                                                   value="presente" 
                                                                   <?php echo ($estudiante['asistencia_estado'] == 'presente') ? 'checked' : ''; ?>>
                                                            <label for="presente_<?php echo $estudiante['id']; ?>">Presente</label>
                                                        </div>
                                                        <div class="attendance-option falta">
                                                            <input type="radio" 
                                                                   id="falta_<?php echo $estudiante['id']; ?>" 
                                                                   name="asistencia[<?php echo $estudiante['id']; ?>]" 
                                                                   value="falta" 
                                                                   <?php echo ($estudiante['asistencia_estado'] == 'falta' || !$estudiante['asistencia_estado']) ? 'checked' : ''; ?>>
                                                            <label for="falta_<?php echo $estudiante['id']; ?>">Falta</label>
                                                        </div>
                                                        <div class="attendance-option tarde">
                                                            <input type="radio" 
                                                                   id="tarde_<?php echo $estudiante['id']; ?>" 
                                                                   name="asistencia[<?php echo $estudiante['id']; ?>]" 
                                                                   value="tarde"
                                                                   <?php echo ($estudiante['asistencia_estado'] == 'tarde') ? 'checked' : ''; ?>>
                                                            <label for="tarde_<?php echo $estudiante['id']; ?>">Tarde</label>
                                                        </div>
                                                        <div class="attendance-option permiso">
                                                            <input type="radio" 
                                                                   id="permiso_<?php echo $estudiante['id']; ?>" 
                                                                   name="asistencia[<?php echo $estudiante['id']; ?>]" 
                                                                   value="permiso" 
                                                                   <?php echo ($estudiante['asistencia_estado'] == 'permiso') ? 'checked' : ''; ?>>
                                                            <label for="permiso_<?php echo $estudiante['id']; ?>">Permiso</label>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <input type="text" 
                                                           class="obs-input"
                                                           name="observaciones[<?php echo $estudiante['id']; ?>]" 
                                                           placeholder="Observaciones..."
                                                           value="<?php echo htmlspecialchars($estudiante['observaciones'] ?? ''); ?>">
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                                
                                <div class="actions">
                                    <button type="submit" class="btn btn-primary">💾 Guardar Asistencia</button>
                                    <button type="button" class="btn btn-success" onclick="marcarTodos('presente')">✓ Todos Presente</button>
                                    <button type="button" class="btn btn-danger" onclick="marcarTodos('falta')">✗ Todos Falta</button>
                                    <button type="button" class="btn btn-warning" onclick="marcarTodos('tarde')">⏰ Todos Tarde</button>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <p>⚠️ No hay estudiantes matriculados en esta unidad didáctica.</p>
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <script>
        function marcarTodos(estado) {
            const radios = document.querySelectorAll(`input[type="radio"][value="${estado}"]`);
            radios.forEach(radio => {
                radio.checked = true;
            });
        }
        
        // Auto-ocultar alertas después de 5 segundos
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.animation = 'slideIn 0.5s ease reverse';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);
    </script>
</body>
</html>